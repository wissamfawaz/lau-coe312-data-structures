//********************************************************************
//  City.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.13 
//********************************************************************

public class City
{
   private double x = 0, y = 0;
   private String name = null;
	
   //------------------------------------------------------------
   //  Sets up this city with the specified coordinates.
   //------------------------------------------------------------
   public City (String name, double x, double y)
   {
      this.name = name;
      this.x = x;
      this.y = y;
   }
	
   //------------------------------------------------------------
   // Returns a string representation of this city.
   //------------------------------------------------------------
   public String toString()
   {
      return name + " (" + x + ", " + y + ")";
   }
	
   //------------------------------------------------------------
   // Returns the distance between this city and the given city.
   //------------------------------------------------------------
   public double getDistance (City c)
   {
      double xDiff = x - c.x;
      double yDiff = y - c.y;
      return Math.sqrt((xDiff * xDiff) + (yDiff * yDiff));
   }
}