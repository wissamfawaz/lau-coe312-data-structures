//********************************************************************
//  DivisorCalcTest.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.2 
//********************************************************************

import java.util.Scanner;

public class DivisorCalcTest
{
   //-----------------------------------------------------------------
   //  Determines the greatest common divsor of pairs of integers.
   //-----------------------------------------------------------------
   public static void main (String args[])
   {
      int num1, num2;
      String another = "y";
        
      Scanner scan = new Scanner(System.in);
        
      while (another.equalsIgnoreCase("y"))
      {
         System.out.print ("Enter first number: ");
         num1 = scan.nextInt();
         System.out.print ("Enter second number: ");
         num2 = scan.nextInt();
         scan.nextLine();  // flush input
            
         System.out.println("GCD of " + num1 + " and " + num2 + " is "
                            + DivisorCalc.gcd(num1, num2));
            
         System.out.print ("Compute another GCD (y/n)? ");
         another = scan.nextLine();
      }
   }
}
