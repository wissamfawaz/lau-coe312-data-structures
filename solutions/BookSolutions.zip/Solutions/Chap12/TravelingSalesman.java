//********************************************************************
//  TravelingSalesman.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.13 
//********************************************************************

public class TravelingSalesman
{
   private int routes = 0;  // number of routes computed

   //----------------------------------------------------------------
   // Finds all possible routes from the city with the given index
   // to the last city in the array. The total distance is returned.
   //----------------------------------------------------------------
   public double findRoute (City[] cities, int startIdx, double dist)
   {
      double distance = dist;
      City start = cities[startIdx];
	
      // For each city between the start city and the next-to-last,
      // swap it to the next spot, compute a route, then swap it
      // back
      for (int i = startIdx + 1; i < (cities.length - 1); i++)
      {
         City next = cities[i];
         cities[i] = cities[startIdx + 1];
         cities[startIdx + 1] = next;
         distance = dist + findRoute(
         cities, startIdx + 1, dist + start.getDistance(next));
         cities[startIdx + 1] = cities[i];	
         cities[i] = next;
      }
	
      // If we're at the next-to-last city print out the distance
      if (startIdx == (cities.length - 2))
      {
         // Include the distance to the last city
         distance += start.getDistance(cities[cities.length - 1]);
	
         // Increment and print the route counter
         routes ++;
         System.out.println("Route # " + routes);
	
         // Print the contents of the array, which will reflect
         // the accumulated route
         for (int i = 0; i < cities.length; i++)
            System.out.println((i + 1) + ": " + cities[i]);
	
         // Finally, print out the total
         System.out.println("Total distance: " + distance);
         System.out.println();
      }
		
      return distance;
   }
	
   //----------------------------------------------------------------
   // Finds and prints all possible routes from the first city in
   // the list to the last city in the list.
   //----------------------------------------------------------------
   public void findRoutes (City[] cities)
   {
      routes = 0;
	
      // Call the recursive method to find the routes, starting at
      // index 0 with initial distance 0
      findRoute(cities, 0, 0.0);
   }
}

