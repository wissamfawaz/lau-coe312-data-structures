//********************************************************************
//  PalindromeEvaluator.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.1 
//********************************************************************

public class PalindromeEvaluator
{
   private String testString;
   
   //-----------------------------------------------------------------
   //  Stores the string to be evaluated.
   //-----------------------------------------------------------------
   public PalindromeEvaluator (String test)
   {
      testString = convertString(test);
   }

   //-----------------------------------------------------------------
   //  Removes all characters except for number and digits and
   //  converts all characters to lowercase.
   //-----------------------------------------------------------------
   private String convertString (String str)
   {
      String str2 = "";
      
      str = str.toLowerCase();

      for (int i=0; i < str.length(); i++)
         if (Character.isLetterOrDigit(str.charAt(i)))
            str2 += str.charAt(i);

      return str2;
   }

   //-----------------------------------------------------------------
   //  Determines if the string is a palindrome.
   //-----------------------------------------------------------------
   public boolean isPalindrome()
   {
      return testPalindrome(0, testString.length()-1);
   }
   
   //-----------------------------------------------------------------
   //  Recursively determines if the string is a palindrome by
   //  testing smaller substrings.
   //-----------------------------------------------------------------
   private boolean testPalindrome (int startIndex, int endIndex)
   {
      boolean result;

      if (endIndex == startIndex || endIndex < startIndex)  // base case
         result = true;
      else
         if (testString.charAt(startIndex) == testString.charAt(endIndex))
            result = testPalindrome(startIndex+1, endIndex-1);
         else
            result = false;

      return result;
   }
}
