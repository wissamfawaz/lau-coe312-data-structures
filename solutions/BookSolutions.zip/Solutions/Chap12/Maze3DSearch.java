//********************************************************************
//  Maze3DSearch.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.4 
//********************************************************************

public class Maze3DSearch
{   
   //-----------------------------------------------------------------
   //  Creates a random maze and attempts to solve it. Repeats until 
   //  a maze is solved and prints out the traversal steps.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      boolean done = false;
      int numMazes = 0;

      while (!done)
      {
         Maze3D labyrinth = new Maze3D();
         numMazes++;

         if (labyrinth.traverseMaze (0, 0, 0))
         {
            System.out.println ("The maze was successfully traversed!");
            System.out.println("Number of mazes generated : " + numMazes);
            done = true;
         }
      }
   }
}
