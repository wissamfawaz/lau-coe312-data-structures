//********************************************************************
//  KochSnowflake.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.10 
//********************************************************************

import java.awt.Dimension;
import java.awt.Graphics;

public class KochSnowflake extends RecursiveFractal
{
   private int order;
    
   private final int MAX_ORDER = 8;
   private final String name = "The Koch Snowflake";
   private final int NUM_COORDINATES = 6;
   private final int TOPX = 0, TOPY = 1, LEFTX = 2, LEFTY = 3, RIGHTX = 4, RIGHTY = 5;
    
   private final int INSET = 20;
   private final int BORDER = 50;
   private final double SQ = Math.sqrt(3.0) / 6;
    
   //-----------------------------------------------------------------
   //  Sets up this fractal with an order of 1.
   //-----------------------------------------------------------------
   public KochSnowflake() 
   {
      order = 1;
   }
    
   //-----------------------------------------------------------------
   //  Sets the fractal order to the value specified.
   //-----------------------------------------------------------------
   public void setOrder(int value)
   {
      if (value < 1)
         order = 1;
      else
         if (value > MAX_ORDER)
            order = MAX_ORDER;
         else
            order = value;
   }
    
   //-----------------------------------------------------------------
   //  Returns the current fractal order.
   //-----------------------------------------------------------------
   public int getOrder()
   {
      return order;
   }
  
   //-----------------------------------------------------------------
   //  Returns the maximum fractal order.
   //-----------------------------------------------------------------
   public int getMaxOrder()
   {
      return MAX_ORDER;
   }
    
   //-----------------------------------------------------------------
   //  Returns the name of the fractal.
   //-----------------------------------------------------------------
   public String getName()
   {
      return name;
   }

   //-----------------------------------------------------------------
   //  Draws the fractal using the graphics context supplied by page. 
   //  The fractal's base is defined by the values in coordinates.
   //
   //  The order of coordinates for the Koch Snowflake is :
   //      topX, topY, leftX, leftY, rightX, rightY
   //-----------------------------------------------------------------
   public void draw(int[] coordinates, Graphics page)
   {
      if (coordinates.length < NUM_COORDINATES)
         return;
        
      drawFractal (order, coordinates[TOPX], coordinates[TOPY], 
                          coordinates[LEFTX], coordinates[LEFTY], page);
      drawFractal (order, coordinates[LEFTX], coordinates[LEFTY],
                          coordinates[RIGHTX], coordinates[RIGHTY], page);
      drawFractal (order, coordinates[RIGHTX], coordinates[RIGHTY],
                          coordinates[TOPX], coordinates[TOPY], page);      
   }

   //-----------------------------------------------------------------
   //  Recursively draws the fractal of specified order.
   //-----------------------------------------------------------------
   private void drawFractal (int order, int x1, int y1, int x5, int y5,
                             Graphics page)
   {
      int deltaX, deltaY, x2, y2, x3, y3, x4, y4;

      if (order == 1)
         page.drawLine (x1, y1, x5, y5);
      else
      {
         deltaX = x5 - x1;  // distance between end points
         deltaY = y5 - y1;

         x2 = x1 + deltaX / 3;  // one third
         y2 = y1 + deltaY / 3;

         x3 = (int) ((x1+x5)/2 + SQ * (y1-y5));  // tip of projection
         y3 = (int) ((y1+y5)/2 + SQ * (x5-x1));

         x4 = x1 + deltaX * 2/3;  // two thirds
         y4 = y1 + deltaY * 2/3;

         drawFractal (order-1, x1, y1, x2, y2, page);
         drawFractal (order-1, x2, y2, x3, y3, page);
         drawFractal (order-1, x3, y3, x4, y4, page);
         drawFractal (order-1, x4, y4, x5, y5, page);
      }
   }
}
