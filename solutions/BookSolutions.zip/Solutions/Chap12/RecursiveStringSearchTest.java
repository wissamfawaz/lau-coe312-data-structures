//********************************************************************
//  RecursiveStringSearchTest.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.12 
//********************************************************************

import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;

public class RecursiveStringSearchTest
{
   //----------------------------------------------------------------
   //  Reads a set of input strings, then prompts for Strings to
   //  search for.
   //----------------------------------------------------------------
   public static void main (String[] args) throws IOException
   {
      // Make an ArrayList to hold the strings
      ArrayList list = new ArrayList();
	
      Scanner scan = new Scanner(System.in);
      System.out.print("Enter a sorted list of strings to be searched. ");
      System.out.println("Enter a blank line when finished.");

      String last = "";
      boolean done = false;
      while (! done)
      {
         System.out.print(Integer.toString(list.size() + 1) + "> ");
         String val = scan.nextLine();
	
         // Stop on an empty line
         if ((val == null) || (val.length() == 0))
            done = true;
         else
            if (val.compareTo(last) < 0)
               System.out.println("ERROR: Strings must be in sorted order.");
            else
            {
               list.add(val);
               last = val;
            }
      }

      // Turn the ArrayList into an array
      String[] vals = new String[list.size()];
      list.toArray(vals);
	
      RecursiveStringSearch searcher = new RecursiveStringSearch();
	
      // Prompt for strings to search for
      System.out.println();
      System.out.print("Enter Strings to search for. ");
      System.out.println("Enter a blank line to quit.");
      System.out.print("> ");
      String line = scan.nextLine();

      while ((line != null) && (line.length() > 0))
      {
         boolean found = searcher.search(line, vals);
         System.out.print("\"" + line + "\" is ");
         if (!found)
            System.out.print("NOT ");
         System.out.print("in the list. List size is " + list.size());
         System.out.print(" and " + searcher.getNumberOfComparisons());
         System.out.println(" comparisons were made.");
         System.out.println();
	
         // Continue prompting until a blank line is entered
         System.out.print("> ");
         line = scan.nextLine();
      }
   }
}



