//********************************************************************
//  PalindromeTester3.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.1
//********************************************************************

import java.util.Scanner;

public class PalindromeTester3
{
   //-----------------------------------------------------------------
   //  Tests strings to see if they are palindromes.
   //-----------------------------------------------------------------
   public static void main (String args[]) 
   {
      String str, another = "y";

	  Scanner scan = new Scanner(System.in);
	
      while (another.equalsIgnoreCase("y"))
      {
         System.out.println ("Enter a potential palindrome:");
         str = scan.nextLine();

         PalindromeEvaluator test = new PalindromeEvaluator (str);
         
         if (test.isPalindrome())
            System.out.println ("That string IS a palindrome.");
         else
            System.out.println ("That string is NOT a palindrome.");

         System.out.println();
         System.out.print ("Test another palindrome (y/n)? ");
         another = scan.nextLine();
      }
   }
}
