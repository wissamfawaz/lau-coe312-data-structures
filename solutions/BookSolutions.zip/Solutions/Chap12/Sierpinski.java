//********************************************************************
//  Sierpinski.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.14 
//********************************************************************

import javax.swing.JFrame;

public class Sierpinski
{
   //-----------------------------------------------------------------
   //  Sets up and displays the main program frame.
   //-----------------------------------------------------------------
   public static void main(String[] args)
   {
      JFrame frame = new JFrame ("Sierpinski Triangle");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add (new SierpinskiPanel());
      frame.pack();
      frame.setVisible(true);
   }
}