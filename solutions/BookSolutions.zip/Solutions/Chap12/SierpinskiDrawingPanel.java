//********************************************************************
//  SierpinskiDrawingPanel.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.14 
//********************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SierpinskiDrawingPanel extends JPanel
{
   private int depth;

   //-----------------------------------------------------------------
   //  Sets up the panel.
   //-----------------------------------------------------------------
   public SierpinskiDrawingPanel(int depthInit)
   {
      depth = depthInit;

      setBackground (Color.white);
      setPreferredSize (new Dimension(500, 500));
   }

   //-----------------------------------------------------------------
   //  Recursive method that removes a triangle from the center of
   //  the given triangle, then calls itself with the corners of the
   //  three resulting triangles.
   //-----------------------------------------------------------------
   private void drawTriangle (Graphics page, Point p1, Point p2, Point p3,
                              int count)
   {
      page.setColor (Color.white);

      // Compute three new corners based on midpoints
      Point newP1 = new Point((p1.x + p2.x)/2, (p1.y + p2.y)/2);
      Point newP2 = new Point((p1.x + p3.x)/2, (p1.y + p3.y)/2);
      Point newP3 = new Point((p2.x + p3.x)/2, (p2.y + p3.y)/2);

      Polygon poly = new Polygon();
      poly.addPoint(newP1.x, newP1.y);
      poly.addPoint(newP2.x, newP2.y);
      poly.addPoint(newP3.x, newP3.y);
      page.fillPolygon(poly);

      // Compute the next step
      count++;
      if (count < depth)
      {
         drawTriangle(page, newP1, newP2, p1, count);
         drawTriangle(page, newP1, p2, newP3, count);
         drawTriangle(page, newP2, p3, newP3, count);
      }
   }

   //-----------------------------------------------------------------
   //  Paints the fractal.
   //-----------------------------------------------------------------
   public void paintComponent (Graphics page)
   {
      super.paintComponent(page);
      Dimension sz = getSize();

      // Figure out the initial three corners
      Point p1 = new Point(sz.width/2, 1);
      Point p2 = new Point(1, sz.height - 1);
      Point p3 = new Point(sz.width - 1, sz.height - 1);
	
      page.setColor(Color.black);
      Polygon poly = new Polygon();
      poly.addPoint(p1.x, p1.y);
      poly.addPoint(p2.x, p2.y);
      poly.addPoint(p3.x, p3.y);
      page.fillPolygon(poly);
	
      drawTriangle(page, p1, p2, p3, 0);
   }

   //-----------------------------------------------------------------
   //  Sets the new depth of the fractal and repaints.
   //-----------------------------------------------------------------
   public void setDepth (int depthUpdate)
   {
      if (depth != depthUpdate)
      {
         depth = depthUpdate;
         repaint();
      }
   }

   //-----------------------------------------------------------------
   //  Returns the depth of the fractal.
   //-----------------------------------------------------------------
   public int getDepth()
   {
      return depth;
   }
}

