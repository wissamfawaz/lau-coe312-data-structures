This folder contains solutions to the Programming Projects from
Chapter 12 of Java Software Solutions, 7th Edition, by Lewis and Loftus.


Project     File(s)
-------     -------

12.1        PalindromeTester3.java
            PalindromeEvaluator.java
		
12.2        DivisorClacTest.java
            DivisorCalc.java

12.3        MazeSeach2.java
            Maze2.java

12.4        Maze3DSearch.java
            Maze3D.java

12.5		TiledPictures2.java 
            TiledPictures2.html
            3 GIF image files

12.6        Queens.java
            QueensEvaluator.java

12.7        Blurbs.java
            BlurbGenerator.java

12.8        Blurbs2.java
            BlurbParser.java

12.9        PascalsTriangle.java
            PascalsTriangleGenerator.java

12.10       FractalApplet.java
            FractalPanel.java
            RecursiveFractal.java
            KochSnowflake.java
            CCurve.java
            FractalApplet.html

12.11       TowersAnimation.java
            TowersAnimationPanel.java
            TowerPanel.java
            TowersOfHanoi.java
            TowersMove.java
            Tower.java
            TowerDisk.java            

12.12       RecursiveStringSearchTest.java
            RecursiveStringSearch.java

12.13       TravelingSalesmanTest.java
            TravelingSalesman.java
            City.java

12.14       Sierpinski.java
            SierpinskiPanel.java
            SierpinskiDrawingPanel.java


