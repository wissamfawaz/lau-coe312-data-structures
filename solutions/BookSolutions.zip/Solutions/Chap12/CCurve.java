//********************************************************************
//  CCurve.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.10 
//********************************************************************

import java.awt.Graphics;

public class CCurve extends RecursiveFractal
{
   private int order;

   private final int MAX_ORDER = 15;
   private final String name = "The C-Curve Fractal";
   private final int NUM_COORDINATES = 4;
   private final int LEFTX = 0, RIGHTX = 1, TOPY = 2, BOTTOMY = 3;

   //-----------------------------------------------------------------
   //  Sets up this fractal with an order of 1.
   //-----------------------------------------------------------------
   public CCurve() 
   {
      order = 1;
   }

   //-----------------------------------------------------------------
   //  Returns the maximum fractal order.
   //-----------------------------------------------------------------
   public int getMaxOrder()
   {
      return MAX_ORDER;
   }
    
   //-----------------------------------------------------------------
   //  Returns the current fractal order.
   //-----------------------------------------------------------------
   public int getOrder()
   {
      return order;
   }
    
   //-----------------------------------------------------------------
   //  Sets the fractal order to the value specified.
   //-----------------------------------------------------------------
   public void setOrder(int value)
   {
      if (value < 1)
         order = 1;
      else
         if (value > MAX_ORDER)
            order = MAX_ORDER;
         else
            order = value;        
   }
    
   //-----------------------------------------------------------------
   //  Returns the name of the fractal.
   //-----------------------------------------------------------------
   public String getName()
   {
      return name;
   }

   //-----------------------------------------------------------------
   //  Draws the fractal using the graphics context supplied by page. 
   //  The fractal's base is defined by the values in coordinates.
   //
   //  The order of coordinates for the C Curve is :
   //      leftX, rightX, topY, bottomY
   //-----------------------------------------------------------------
   public void draw(int[] coordinates, Graphics page)
   {
      if (coordinates.length < NUM_COORDINATES)
         return;
        
      drawFractal(order, coordinates[LEFTX], coordinates[TOPY], 
                         coordinates[LEFTX], coordinates[BOTTOMY], page);
      drawFractal(order, coordinates[LEFTX], coordinates[BOTTOMY], 
                         coordinates[RIGHTX], coordinates[BOTTOMY], page);
      drawFractal(order, coordinates[RIGHTX], coordinates[BOTTOMY], 
                         coordinates[RIGHTX], coordinates[TOPY], page);
   }
    
   //-----------------------------------------------------------------
   //  Recursively draws the fractal of specified order.
   //-----------------------------------------------------------------
   private void drawFractal (int order, int x1, int y1, int x3, int y3,
                             Graphics page)    
   {
      int x2, y2;
        
      if (order == 1)
         page.drawLine(x1, y1, x3, y3);
      else
      {
         x2 = (x1 + x3 + y1 - y3) / 2;
         y2 = (x3 + y1 + y3 - x1) / 2;
            
         drawFractal(order - 1, x1, y1, x2, y2, page);
         drawFractal(order - 1, x2, y2, x3, y3, page);
      }
   }
}
