//********************************************************************
//  PascalsTriangle.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.9 
//********************************************************************

import java.util.Scanner;

public class PascalsTriangle
{
   //-----------------------------------------------------------------
   //  Generates and prints the row of Pascal's Triangle requested
   //  by the user.
   //-----------------------------------------------------------------    
   public static void main (String args[]) 
   {
      String another = "y";
      Scanner scan = new Scanner(System.in);
	  
      while (another.equalsIgnoreCase("y"))
      {
         System.out.print ("Which line number of Pascal's Triangle? ");
         int row = scan.nextInt();
         String flush = scan.nextLine();

         PascalsTriangleGenerator p = new PascalsTriangleGenerator();
         int[] result = p.computeRow(row);

         System.out.println("Line " + row + " of Pascal's Triangle:");
         for (int num : result)
            System.out.print(num + " ");   
            
         System.out.print ("\nAnother (y/n)? ");
         another = scan.nextLine();
      }     
   }
}
