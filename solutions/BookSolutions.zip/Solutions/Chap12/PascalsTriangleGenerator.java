//********************************************************************
//  PascalsTriangleGenerator.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.9 
//********************************************************************

import java.util.Scanner;

public class PascalsTriangleGenerator
{    
   private int[] nums, newRow;
    
   //-----------------------------------------------------------------
   //  Creates the initial row of Pascal's triangle.
   //-----------------------------------------------------------------
   public PascalsTriangleGenerator()
   {
      nums = new int[1];
      nums[0] = 1;
   }
    
   //-----------------------------------------------------------------
   //  Recursively computes the specified row of Pascal's Triangle. 
   //-----------------------------------------------------------------
   public int[] computeRow (int rowToCompute)
   {
      if (rowToCompute == 1)  // base case
         return nums;
      else
         return (computeNextRow(computeRow(rowToCompute-1)));

   //-----------------------------------------------------------------
   //  Computes the next row of Pascal's Triangle given the previous
   //  one.
   //-----------------------------------------------------------------
   public int[] computeNextRow (int[] previousRow)
   {
      nextRow = new int[previousRow.length+1];  // one more than the row above
      nextRow[0] = 1;

      for (int i=1; i < nextRow.length; i++)
         nextRow[i] = previousRow[i-1] + nums[i];

      nextRow[previousRow.length] = 1;

      return nextRow;
    }
}
