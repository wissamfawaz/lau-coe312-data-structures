//********************************************************************
//  SierpinskiPanel.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.14 
//********************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class SierpinskiPanel extends JPanel implements 
    ChangeListener,   // To listen for changes to the slider
    ComponentListener // To reset the slider based on fractal size
{
   private int INITIAL_DEPTH = 4;
   private SierpinskiDrawingPanel fractal = null;
   private JSlider depth = null;

   //-----------------------------------------------------------------
   //  Sets up the drawing panel and slider.
   //-----------------------------------------------------------------
   public SierpinskiPanel()
   {
      fractal = new SierpinskiDrawingPanel(INITIAL_DEPTH);
      fractal.addComponentListener(this);

      depth = new JSlider(1, 5);
      depth.setPaintTicks(true);
      depth.setPaintLabels(true);
      depth.setSnapToTicks(true);
      depth.setValue(INITIAL_DEPTH);
      depth.addChangeListener(this);

      setLayout (new BorderLayout());
      add (fractal, BorderLayout.CENTER);
      add (depth, BorderLayout.SOUTH);
   }

   //-----------------------------------------------------------------
   //  Changes the depth of the fractal when the slider value changes.
   //-----------------------------------------------------------------
   public void stateChanged(ChangeEvent event)
   {
      fractal.setDepth(depth.getValue());
   }

   //-----------------------------------------------------------------
   //  Resets the slider valudes when the fractal panel is resized.
   //-----------------------------------------------------------------
   public void componentResized(ComponentEvent event)
   {
      resetSliderValues();
   }

   //-----------------------------------------------------------------
   //  Resets the slider values when the fractal panel is shown.
   //-----------------------------------------------------------------
   public void componentShown(ComponentEvent event)
   {
      resetSliderValues();
   }

   public void componentMoved (ComponentEvent event) { }
   public void componentHidden (ComponentEvent event) { }

   //-----------------------------------------------------------------
   //  Resets the slider values based on the size of the fractal.
   //-----------------------------------------------------------------
   private void resetSliderValues()
   {
      depth.setMinimum(1);

      //  Compute the maximum depth based on the smaller of the width
      //  and height
      Dimension sz = fractal.getSize();
      int minDim = Math.min(sz.width, sz.height);

      //  Set the maximum to one less than log (base 2) of the min dimension
      depth.setMaximum((int) (Math.log(minDim)/Math.log(2)) - 1);

      depth.setLabelTable(depth.createStandardLabels(1));

      //  Make sure we're still in range
      if (fractal.getDepth() > depth.getMaximum())
         depth.setValue(depth.getMaximum());
   }
}