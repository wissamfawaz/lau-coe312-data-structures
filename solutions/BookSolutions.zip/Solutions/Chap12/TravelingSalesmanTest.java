//********************************************************************
//  TravelingSalesmanTest.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.13 
//********************************************************************

import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.MatchResult;
import java.util.InputMismatchException;

public class TravelingSalesmanTest
{
   //----------------------------------------------------------------
   // Demonstration of the travelling salesman problem. For a given list
   // of cities with coordinates, all possible routes from the first
   // city to the last city are displayed along with the total length of 
   // each route.
   //----------------------------------------------------------------
   public static void main(String[] args) throws IOException
   {
      ArrayList list = new ArrayList();
	
      // Make a Pattern describing a valid city name 
      Pattern cityPattern = Pattern.compile("(\\D+)");
	
      System.out.println("Enter city names, followed by x and y coordinate values.");
      System.out.println("Enter a blank line when you are finished.");
      Scanner scan = new Scanner(System.in);
		
      // Read and parse lines, populating the cities list
      String line = scan.nextLine();
      while ((line != null) && (line.length() > 0))
      {
         Scanner scan2 = new Scanner(line);
         City city = new City(scan2.findInLine(cityPattern), scan2.nextDouble(),
                              scan2.nextDouble());
         list.add(city);
         line = scan.nextLine();
      }
	
      // Make sure they entered at least two cities
      if (list.size() < 2)
         System.out.println("You must enter at least two cities");
      else
      {
         City[] cities = new City[list.size()];
         list.toArray(cities);
         TravelingSalesman ts = new TravelingSalesman();
         ts.findRoutes(cities);
      }
   }
}

