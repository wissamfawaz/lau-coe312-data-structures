//********************************************************************
//  Blurbs2.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.8 
//********************************************************************

import java.util.Scanner;

public class Blurbs2
{
   //-----------------------------------------------------------------
   //  Reads potential blurbs and determines if they fit the
   //  proper syntactic definition of a blurb.
   //-----------------------------------------------------------------
   public static void main (String args[]) 
   {
      BlurbParser parser = new BlurbParser();
      Scanner scan = new Scanner(System.in);
       
      String another = "y";
      while (another.equalsIgnoreCase("y"))
      {
         System.out.println("Enter a Blurb:");
         String blurb = scan.nextLine();

         if (parser.isABlurb(blurb))
           System.out.println(blurb + " IS a valid Blurb");
         else
            System.out.println(blurb + " is NOT a valid Blurb");

         System.out.println("Parse another Blurb (y/n/)?");
         another = scan.nextLine();
      }
   }
}
