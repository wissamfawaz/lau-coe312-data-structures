//********************************************************************
//  Queens.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.6 
//********************************************************************

public class Queens
{
   //-----------------------------------------------------------------
   //  Invokes the evaluator method to show solutions to the
   //  Non-Attacking Queens problem.
   //-----------------------------------------------------------------
   public static void main (String args[])
   {
      QueensEvaluator qe = new QueensEvaluator();
      qe.showSolutions();
   }
}
