//********************************************************************
//  RecursiveStringSearch.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.12 
//********************************************************************

import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;

public class RecursiveStringSearch
{
   private int comparisons = 0;

   //----------------------------------------------------------------
   //  Performs a recursive binary search of the list of Strings,
   //  returning true if the given String is found in the array
   //  between the two given indices.
   //----------------------------------------------------------------
   public boolean search (String str, String[] list, int startIdx,
                          int endIdx)
   {
      boolean result = false;
	
      // If our startIdx is after our endIdx, then we've determined
      // that the string cannot be in the list.
      if (startIdx <= endIdx)
      {
         // Compare the string to the element in the middle of the range
         // of the list.
         int midIdx = (startIdx + endIdx)/2;
         String mid = list[midIdx];
         int comp = mid.compareTo(str);
	
         comparisons++;
	
         // If the strings are equal then we're done. Otherwise call
         // search(...) again, cutting the range of indices in half.
         if (comp == 0)
            result = true;
         else if (comp < 0)
			result = search(str, list, midIdx + 1, endIdx);
         else
            result = search(str, list, startIdx, midIdx - 1);
      }

      return result;
   }

   //----------------------------------------------------------------
   // Performs a search of the list of Strings, returning
   // true if the given String is found in the array.
   //----------------------------------------------------------------
   public boolean search (String str, String[] list)
   {
      comparisons = 0;  // reset comparison count
      return search(str, list, 0, list.length - 1);
   }

   //----------------------------------------------------------------
   // Returns the number of comparisons made in the last search.
   //----------------------------------------------------------------
   public int getNumberOfComparisons()
   {
      return comparisons;
   }
}



