//********************************************************************
//  FractalApplet.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.10 
//********************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class FractalApplet extends JApplet
{
   private JButton increase, decrease, foreground, background;
   private JLabel titleLabel, orderLabel;
   private FractalPanel drawing;
   private JMenuItem koch, cCurve;
   private JPanel appletPanel;

   //-----------------------------------------------------------------
   //  Sets up the components for the applet.
   //-----------------------------------------------------------------
   public void init()
   {
      drawing = new FractalPanel (1);
      
      setJMenuBar(createMenuBar());
      
      appletPanel = new JPanel();
      appletPanel.setLayout (new BorderLayout());

      appletPanel.add (createToolsPanel(), BorderLayout.NORTH);
      appletPanel.add (drawing, BorderLayout.CENTER);
      appletPanel.add (createColorButtonsPanel(), BorderLayout.SOUTH);

      getContentPane().add (appletPanel);
   }

   //-----------------------------------------------------------------
   //  Creates the tool bar panel.
   //-----------------------------------------------------------------   
   private JPanel createToolsPanel()
   {
      JPanel tools = new JPanel ();
      tools.setLayout (new BoxLayout(tools, BoxLayout.X_AXIS));
      tools.setBackground (Color.yellow);
      tools.setOpaque (true);

      titleLabel = new JLabel (drawing.getTitle());
      titleLabel.setForeground (Color.black);

      OrderButtonListener orderListener = new OrderButtonListener();
      increase = new JButton("+");
      increase.setMargin (new Insets (5, 5, 5, 5));
      increase.addActionListener (orderListener);

      decrease = new JButton("-");
      decrease.setMargin (new Insets (5, 5, 5, 5));
      decrease.addActionListener (orderListener);

      orderLabel = new JLabel ("Order: 1");
      orderLabel.setForeground (Color.black);

      tools.add (Box.createHorizontalStrut (20));
      tools.add (titleLabel);
      tools.add (Box.createHorizontalStrut (20));
      tools.add (decrease);
      tools.add (increase);
      tools.add (Box.createHorizontalStrut (20));
      tools.add (orderLabel);
      
      return tools;
   }

   //-----------------------------------------------------------------
   //  Creates the menu bar.
   //-----------------------------------------------------------------   
   private JMenuBar createMenuBar()
   {
      MenuListener menuListen = new MenuListener();
      
      JMenuBar menu = new JMenuBar();
      JMenu designs = new JMenu("Pick Fractal Design");
      designs.setMnemonic('d');
      
      koch = new JMenuItem("Koch Snowflake");
      cCurve = new JMenuItem("C-Curve");
      
      koch.setMnemonic('k');
      cCurve.setMnemonic('c');
      
      koch.addActionListener(menuListen);
      cCurve.addActionListener(menuListen);
      
      designs.add(koch);
      designs.add(cCurve);
      menu.add(designs);
      
      return menu;
   }
   
   //-----------------------------------------------------------------
   //  Creates the buttons used to change colors.
   //-----------------------------------------------------------------
   private JPanel createColorButtonsPanel()
   {
      JPanel colorPanel = new JPanel();
      
      ColorButtonListener colorListener = new ColorButtonListener();
      foreground = new JButton ("Change Foreground");
      foreground.addActionListener(colorListener);
      background = new JButton ("Change Background");
      background.addActionListener(colorListener);
      colorPanel.add (foreground);
      colorPanel.add (background);
      
      colorPanel.setBackground (Color.black);
      return colorPanel;
   }

   //********************************************************************
   //  Listener for the order buttons.
   //********************************************************************
   private class OrderButtonListener implements ActionListener
   {
      //-----------------------------------------------------------------
      //  Determines which button was pushed and makes adjustements.
      //-----------------------------------------------------------------
      public void actionPerformed(ActionEvent event)
      {
         Object source = event.getSource();
         int order = drawing.getOrder();
         if (source == increase)
            order++;
         else
            if (source == decrease)
               order--;

         if (order >= 1 && order <= drawing.getMaxOrder())
         {
            orderLabel.setText ("Order: " + order);
            drawing.setOrder (order);
            repaint();
         }
      }
   }
    
   //********************************************************************
   //  Listener for the color buttons.
   //********************************************************************   
   private class ColorButtonListener implements ActionListener 
   {
      //-----------------------------------------------------------------
      //  Opens a JColorChooser dialog and sets the appropriate color.
      //-----------------------------------------------------------------
      public void actionPerformed(ActionEvent event)
      {
         Object source = event.getSource();

         if (source == foreground)
            drawing.setForeground(JColorChooser.showDialog(null, "Set Foreground Color", drawing.getForeground()));
         else
            drawing.setBackground(JColorChooser.showDialog(null, "Set Background Color", drawing.getBackground()));
         repaint();
      }
   }
    
   //********************************************************************
   //  Listener for the menu items.
   //********************************************************************   
   class MenuListener implements ActionListener
   {
      //-----------------------------------------------------------------
      //  Determines which menu item was chosen and changes the fractal.
      //-----------------------------------------------------------------
      public void actionPerformed(ActionEvent event)
      {
         Object source = event.getSource();
           
         if (source == koch)
            drawing.setDesign(RecursiveFractal.KOCH);
         else
            if (source == cCurve)
               drawing.setDesign(RecursiveFractal.C_CURVE);

         titleLabel.setText(drawing.getTitle());
           
         if (drawing.getOrder() > drawing.getMaxOrder())
         {
            drawing.setOrder(drawing.getMaxOrder());
            orderLabel.setText ("Order: " + drawing.getOrder());
         }

         repaint();
      }
   }
}