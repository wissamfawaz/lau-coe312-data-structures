//********************************************************************
//  DivisorCalc.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.2 
//********************************************************************

public class DivisorCalc
{
   //-----------------------------------------------------------------
   //  Recursively computes the greatest common divisor of the
   //  specified integers. Uses Euclid's algorithm.
   //-----------------------------------------------------------------
   public static int gcd (int num1, int num2)
   {
      if (num2 % num1 == 0)
         return num1;
      else
         return gcd(num2, num1 % num2);
    }
}

