//********************************************************************
//  BlurbParser.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.8
//
//  In the language of an alien race, all words take the form of Blurbs.
//  A Blurb is a Whoozit followed by one or more Whatzits.
//  A Whoozit is the character 'x' followed by zero or more 'y's.
//  A Whatzit is a 'q' followed by either a 'z' or a 'd', followed
//  by a Whoozit.
//********************************************************************

public class BlurbParser
{
   //-----------------------------------------------------------------
   //  Parses a Blurb.
   //-----------------------------------------------------------------    
   public boolean isABlurb(String aString)
   {
      return parseWhoozit(aString);
   }

   //-----------------------------------------------------------------
   //  Parses a Whoozit.
   //-----------------------------------------------------------------
   private boolean parseWhoozit (String aString)
   {
      int charIndex = 0;
      if (aString.length() < 1)
         return false;  // too short
      if (aString.charAt(charIndex++) == 'x')
      {
         while (charIndex < aString.length() && aString.charAt(charIndex) == 'y')
            charIndex++;
         if (charIndex >= aString.length())  // done
            return true;
         if (aString.charAt(charIndex) == 'q')  // valid Whatzit
            return parseWhatzit(aString.substring(charIndex));
         else
            return false; // not followed by a Whatzit
      }
      else
         return false; // does not begin with 'x'
   }

   //-----------------------------------------------------------------
   //  Parses a Whatzit.
   //-----------------------------------------------------------------
   private boolean parseWhatzit (String aString)
   {
      if (aString.length() >= 3)  // long enough
         if (aString.charAt(0) ==  'q')
            if (aString.charAt(1) == 'z' || aString.charAt(1) == 'd')
               return parseWhoozit(aString.substring(2));

      return false;  // does not begin with 'q'
   }
}
