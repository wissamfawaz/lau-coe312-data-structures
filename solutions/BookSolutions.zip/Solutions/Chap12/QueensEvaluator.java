//********************************************************************
//  QueensEvaluator.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.6 
//********************************************************************

public class QueensEvaluator
{
   private int[] queens;   //  queens[i] stores the column of the
                            //  ith row where the ith queen is
    
   final int NUM_QUEENS = 8;
 
   //-----------------------------------------------------------------
   //  Creates the queens array for tracking locations. 
   //----------------------------------------------------------------- 
   public QueensEvaluator()
   {
      queens = new int[NUM_QUEENS];
   }

   //-----------------------------------------------------------------
   //  Returns true if a queen queenNumber can be placed in column.
   //----------------------------------------------------------------- 
   boolean canPlace(int queenNumber, int column)
   {
      // check all rows above queenNumber row
      for (int row = 0; row < queenNumber; row++)
      {
         // in the same column?
         if (queens[row] == column)
            return false;

         // in the same diagonal?
         if (Math.abs(queens[row] - column) == Math.abs(row - queenNumber))
            return false;
      }
      return true;
   }
    
   //-----------------------------------------------------------------
   //  Starting with the row represented by queenNumber, find all 
   //  correct placements in the row and below the row.
   //-----------------------------------------------------------------
   public void solve (int queenNumber)
   {
      // check all columns
      for (int column = 0; column < NUM_QUEENS; column++)
      {
         if (canPlace(queenNumber, column))
         {
            queens[queenNumber] = column;  // place queen in current column

            if (queenNumber + 1 >= NUM_QUEENS)  // solved
               printSolution();
            else    // keep looking
               solve(queenNumber + 1);
         }
      }
   }

   //-----------------------------------------------------------------
   //  Computes and displays all solutions to the problem.
   //-----------------------------------------------------------------    
   public void showSolutions()
   {
      solve(0);  // start with the first row
   }
    
   //-----------------------------------------------------------------
   //  Prints a grid showing the postion of the queens on the board.  
   //  Queen = X.  Empty space = 0.
   //-----------------------------------------------------------------    
   private void printSolution()
   {
      int column;

      for (int row=0; row < NUM_QUEENS; row++)
      {
         for (column = 0; column < NUM_QUEENS; column++)
             if (queens[row] == column)
                System.out.print(" X");
             else 
                System.out.print(" 0");
         System.out.print("\n");
      }

      System.out.println("-----------------------");
   }
}
