//********************************************************************
//  FractalPanel.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.10 
//********************************************************************

import java.awt.*;
import javax.swing.JPanel;

public class FractalPanel extends JPanel
{
   private final int PANEL_WIDTH = 400, PANEL_HEIGHT = 400;

   private final int TOPX = 200, TOPY = 20;
   private final int LEFTX = 60, LEFTY = 300;
   private final int RIGHTX = 340, RIGHTY = 300;

   private final int BORDER = 20;
   private final int NUM_FRACTALS = 2;
   
   private final int DEFAULT_DESIGN = RecursiveFractal.KOCH;
   private final int DEFAULT_ORDER = 9;

   private int current;  // current order
   private int design;

   private Color foreground;
   private Color background;
   
   RecursiveFractal[] fractals;

   //-----------------------------------------------------------------
   //  Sets the initial fractal order to the value specified.
   //-----------------------------------------------------------------
   public FractalPanel(int currentOrder)
   {
      current = currentOrder;
      foreground = Color.green;
      background = Color.black;
      design = DEFAULT_DESIGN;
      
      fractals = new RecursiveFractal[NUM_FRACTALS];
      fractals[RecursiveFractal.KOCH] = new KochSnowflake();
      fractals[RecursiveFractal.C_CURVE] = new CCurve();
      
      setBackground (background);
      setPreferredSize (new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
   }

   //-----------------------------------------------------------------
   //  Draws the current fractal.
   //-----------------------------------------------------------------
   public void paintComponent (Graphics page)
   {
      super.paintComponent (page);
      page.setColor (foreground);
      
      if (design == RecursiveFractal.KOCH)
      {

         fractals[RecursiveFractal.KOCH].setOrder(current);
         int[] coordinates = { TOPX, TOPY, LEFTX, LEFTY, RIGHTX, RIGHTY };
         fractals[RecursiveFractal.KOCH].draw(coordinates, page);
      }
      else
         if (design == RecursiveFractal.C_CURVE)
         {

            fractals[RecursiveFractal.C_CURVE].setOrder(current);
            int segmentLength = getWidth() / 3 - BORDER;
            int leftX = (getWidth() - segmentLength) / 2;
            int rightX = leftX + segmentLength;
            int topY = (getHeight() - segmentLength) / 2;
            int bottomY = topY + segmentLength;

            int[] coordinates = { leftX, rightX, topY, bottomY };
              
            fractals[RecursiveFractal.C_CURVE].draw(coordinates, page);
         }
   }

   //-----------------------------------------------------------------
   //  Sets the fractal order to the value specified.
   //-----------------------------------------------------------------
   public void setOrder (int order)
   {
      current = order;
   }

   //-----------------------------------------------------------------
   //  Returns the current order.
   //-----------------------------------------------------------------
   public int getOrder ()
   {
      return current;
   }

   //-----------------------------------------------------------------
   //  Sets the background to the color specified.
   //-----------------------------------------------------------------   
   public void setBackground(Color color)
   {
      background = color;
   }
   
   //-----------------------------------------------------------------
   //  Returns the current background color.
   //-----------------------------------------------------------------   
   public Color getBackground()
   {
      return background;
   }
   
   //-----------------------------------------------------------------
   //  Sets the foreground to the color specified.
   //-----------------------------------------------------------------   
   public void setForeground(Color color)
   {
      foreground = color;
   }
   
   //-----------------------------------------------------------------
   //  Returns the current foreground color.
   //-----------------------------------------------------------------   
   public Color getForeground()
   {
      return foreground;
   }
   
   //-----------------------------------------------------------------
   //  Sets the fractal design type.
   //-----------------------------------------------------------------   
   public void setDesign(int type)
   {
      design = type;
   }
   
   //-----------------------------------------------------------------
   //  Returns the fractal design type.
   //-----------------------------------------------------------------   
   public int getDesign()
   {
      return design;
   }
   
   //-----------------------------------------------------------------
   //  Returns the maximum order for the currently selected fractal.
   //-----------------------------------------------------------------   
   public int getMaxOrder()
   {
      if (design == RecursiveFractal.KOCH)
         return fractals[RecursiveFractal.KOCH].getMaxOrder();
      if (design == RecursiveFractal.C_CURVE)
         return fractals[RecursiveFractal.C_CURVE].getMaxOrder();
      else 
         return DEFAULT_ORDER;
   }
   
   //-----------------------------------------------------------------
   //  Returns the title of the currently selected fractal.
   //-----------------------------------------------------------------   
   public String getTitle()
   {
      if (design == RecursiveFractal.KOCH)
         return fractals[RecursiveFractal.KOCH].getName();
      if (design == RecursiveFractal.C_CURVE)
         return fractals[RecursiveFractal.C_CURVE].getName();
      else 
         return "Error";
   }
}
