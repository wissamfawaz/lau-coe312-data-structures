//********************************************************************
//  RecursiveFractal.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 12.10 
//********************************************************************

import java.awt.Graphics;

abstract class RecursiveFractal
{
    public static final int KOCH = 0, C_CURVE = 1;   
    
   //-----------------------------------------------------------------
   //  Returns the current fractal order.
   //-----------------------------------------------------------------
    public abstract int getOrder();
    
   //-----------------------------------------------------------------
   //  Sets the fractal order to the value specified.
   //-----------------------------------------------------------------
    public abstract void setOrder(int order);
    
   //-----------------------------------------------------------------
   //  Returns the maximum fractal order.
   //-----------------------------------------------------------------
    public abstract int getMaxOrder();
    
   //-----------------------------------------------------------------
   //  Returns the name of the fractal.
   //-----------------------------------------------------------------
    public abstract String getName();
    
   //-----------------------------------------------------------------
   //  Draws the fractal using the graphics context supplied by page. 
   //  The fractal's base is defined by the values in coordinates.
   //-----------------------------------------------------------------
    public abstract void draw(int[] coordinates, Graphics page);    
}

