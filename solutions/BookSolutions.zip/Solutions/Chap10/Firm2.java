//********************************************************************
//  Firm2.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.1 
//********************************************************************

public class Firm2
{
   //-----------------------------------------------------------------
   //  Creates a staff of employees for a firm and pays them.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      Staff2 personnel = new Staff2();
      personnel.payday();
   }
}
