//********************************************************************
//  SteppedSort2.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.7
//********************************************************************

import java.awt.*;

public class SteppedSort2
{
   private int[] numbers;
   private int index;

   //-----------------------------------------------------------------
   //  Sets up the sort engine.
   //-----------------------------------------------------------------
   public SteppedSort2(int[] unsortedArray)
   {
      numbers = unsortedArray;
      index = 0;
   }

   //-----------------------------------------------------------------
   //  Performs one step of the insertion sort algorithm.
   //-----------------------------------------------------------------
   public void nextStep()
   {
      int key = numbers[index];
      int position = index;

      // shift larger values to the right
      while (position > 0 && numbers[position-1] > key)
      {
         numbers[position] = numbers[position-1];
         position--;
      }

      numbers[position] = key;
      index++;
   }

   //-----------------------------------------------------------------
   //  Returns true if all integers in array are sorted.
   //-----------------------------------------------------------------
   public boolean sortFinished()
   {
      return (index >= numbers.length);
   }

   //-----------------------------------------------------------------
   //  Draws a graphical representation of the ongoing sort.
   //-----------------------------------------------------------------
   public void draw(Graphics page, int width, int height)
   {
      if (sortFinished())
         page.drawString("Finished Sort", 10, height - 10);

      int step = width / (numbers.length + 1);

      for (int i=0; i < numbers.length; i++)
      {
         page.setColor(Color.blue);
         page.drawLine((i+1)*step, 0, (i+1)*step, numbers[i]);
      }
   }
}
