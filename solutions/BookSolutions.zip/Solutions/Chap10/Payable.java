//********************************************************************
//  Payable.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.1 
//********************************************************************

public interface Payable
{
   public abstract double pay();
}
