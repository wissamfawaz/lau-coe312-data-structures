//********************************************************************
//  Speaker.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.3 
//********************************************************************

public interface Speaker
{
   public abstract void speak();
   public abstract void announce (String str);
}
