//********************************************************************
//  Firm3.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.2 
//********************************************************************

public class Firm3
{
   //-----------------------------------------------------------------
   //  Creates a staff of employees for a firm and pays them.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      Staff3 personnel = new Staff3();
      personnel.payday();
   }
}
