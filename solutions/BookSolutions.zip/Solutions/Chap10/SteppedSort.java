//********************************************************************
//  SteppedSort.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.6 
//********************************************************************

import java.awt.*;

public class SteppedSort
{
   private int[] numbers;
   private int index;

   //-----------------------------------------------------------------
   //  Sets up the sort engine.
   //-----------------------------------------------------------------
   public SteppedSort(int[] unsortedArray)
   {
      numbers = unsortedArray;
      index = 0;
   }

   //-----------------------------------------------------------------
   //  Performs one step of the selection sort algorithm.
   //-----------------------------------------------------------------
   public void nextStep()
   {
      int min, temp;
      if (index < numbers.length-1)
      {
         min = index;
         for (int scan = index+1; scan < numbers.length; scan++)
            if (numbers[scan] < numbers[min])
               min = scan;

         // Swap the values
         temp = numbers[min];
         numbers[min] = numbers[index];
         numbers[index] = temp;
         index++;
      }
   }

   //-----------------------------------------------------------------
   //  Returns true if all integers in array are sorted.
   //-----------------------------------------------------------------
   public boolean sortFinished()
   {
      return (index >= numbers.length-1);
   }

   //-----------------------------------------------------------------
   //  Draws a graphical representation of the ongoing sort.
   //-----------------------------------------------------------------
   public void draw(Graphics page, int width, int height)
   {
      if (sortFinished())
         page.drawString("Finished Sort", 10, height - 10);

      int step = width / (numbers.length + 1);

      for (int i=0; i < numbers.length; i++)
      {
         page.setColor(Color.blue);
         page.drawLine((i+1)*step, 0, (i+1)*step, numbers[i]);
      }
   }
}
