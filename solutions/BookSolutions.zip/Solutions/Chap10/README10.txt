This folder contains solutions to the Programming Projects from
Chapter 10 of Java Software Solutions, 7th Edition, by Lewis and Loftus.

Project     File(s)
-------     -------

10.1        Firm2.java
            Payable.java
            Staff2.java
            StaffMember2.java
            Volunteer2.java
            Employee2.java
            Executive2.java
            Hourly2.java

10.2        Firm3.java
            Staff3.java
            StaffMember3.java
            Volunteer3.java
            Employee3.java
            Executive3.java
            Hourly3.java

10.3        SpeakerTest.java
            Speaker.java
            Dog.java
            Philosopher.java

10.4        PhoneList3.java
            Contact.java
            Sorting2.java

10.5        SortedMovies.java
            SortedDVDCollection.java
            SortableDVD.java
            Sorting.java

10.6        SortAnimation.java
            SortAnimationPanel.java
            SteppedSort.java

10.7        SortAnimation2.java
            SortAnimationPanel2.java
            SteppedSort2.java
		
10.8        StyleQuoteOptions.java
            StyleQuoteOptionsPanel.java

10.9        EquationGraph.java
            EquationGraphPanel.java
            EquationViewportPanel.java
            Equation.java
		
		
		