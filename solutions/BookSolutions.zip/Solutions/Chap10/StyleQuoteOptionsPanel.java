//********************************************************************
//  StyleQuoteOptionsPanel.java       Author: Lewis/Loftus
//
// Solution to Programming Project 10.8 
//********************************************************************

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
      
public class StyleQuoteOptionsPanel extends JPanel
{
   private final int MIN_FONT_SIZE = 10, 
                     MAX_FONT_SIZE = 62,
                     INITIAL_FONT_SIZE = 28,
                     FONT_MAJOR_TICK = 10,
                     FONT_MINOR_TICK = 2;

   private JRadioButton comedy, philosophy, carpentry;
   private String comedyQuote = " Take my wife, please.";
   private String philosophyQuote = " I think, therefore I am.";
   private String carpentryQuote = " Measure twice. Cut once.";
   
   private JLabel quote;
   private JCheckBox bold, italic;
   private JPanel primary;
   private JSlider fontSize;
    
   public StyleQuoteOptionsPanel()
   {
      quote = new JLabel (comedyQuote);
      quote.setFont (new Font ("Helvetica", Font.PLAIN, INITIAL_FONT_SIZE));

      JPanel quotePanel = new JPanel();
      quotePanel.setBackground (Color.green);
      quotePanel.setPreferredSize (new Dimension(600, 100));
      quotePanel.add (quote);

      setLayout(new BorderLayout());
      add(quotePanel, BorderLayout.CENTER);
      add(createQuoteSelectionPanel(), BorderLayout.NORTH);
      add(createStyleOptionsPanel(), BorderLayout.SOUTH);

      setBackground (Color.green);
      setPreferredSize (new Dimension(600, 175));
   }
   
   //-----------------------------------------------------------------
   //  Creates the quote selection radio button panel.
   //-----------------------------------------------------------------
   private JPanel createQuoteSelectionPanel()
   {
      comedy = new JRadioButton ("Comedy", true);
      philosophy = new JRadioButton ("Philosophy");
      carpentry = new JRadioButton ("Carpentry");

      ButtonGroup group = new ButtonGroup();
      group.add (comedy);
      group.add (philosophy);
      group.add (carpentry);

      QuoteListener qListener = new QuoteListener();
      comedy.addActionListener (qListener);
      philosophy.addActionListener (qListener);
      carpentry.addActionListener (qListener);

      JPanel buttonPanel = new JPanel();
      buttonPanel.setBackground (Color.green);

      buttonPanel.add (comedy);
      buttonPanel.add (philosophy);
      buttonPanel.add (carpentry);

      return buttonPanel;
   }

   //-----------------------------------------------------------------
   //  Creates the panel used to set the style options.
   //-----------------------------------------------------------------
   private JPanel createStyleOptionsPanel()
   {
      bold = new JCheckBox ("Bold");
      bold.setToolTipText("Check here to make the text bold");
      italic = new JCheckBox ("Italic");
      italic.setToolTipText("Check here to make the text italic");

      StyleListener listener = new StyleListener();
      bold.addItemListener (listener);
      italic.addItemListener (listener);

      // create font slider
      fontSize = new JSlider(JSlider.HORIZONTAL, MIN_FONT_SIZE, MAX_FONT_SIZE,
         INITIAL_FONT_SIZE);
      fontSize.setMajorTickSpacing(FONT_MAJOR_TICK);
      fontSize.setMinorTickSpacing(FONT_MINOR_TICK);
      fontSize.setPaintTicks(true);
      fontSize.setSnapToTicks(true);
      fontSize.setBorder(new TitledBorder("Font Size"));
      fontSize.addChangeListener(new SliderListener());
      
      JPanel stylePanel = new JPanel();
      stylePanel.setBackground (Color.green);

      stylePanel.add(bold);
      stylePanel.add(italic);
      stylePanel.add(fontSize);
      
      return stylePanel;
   }

   //-----------------------------------------------------------------
   //  Sets the font of the quote.
   //-----------------------------------------------------------------
   private void setFont()
   {
      int style = Font.PLAIN;

      if (bold.isSelected())
         style = Font.BOLD;

      if (italic.isSelected())
         style += Font.ITALIC;

      quote.setFont (new Font ("Helvetica", style, fontSize.getValue()));
   }
   
   //*****************************************************************
   //  Represents the listener for both check boxes.
   //*****************************************************************
   private class StyleListener implements ItemListener
   {
      //--------------------------------------------------------------
      //  Updates the style of the label font style.
      //--------------------------------------------------------------
      public void itemStateChanged (ItemEvent event)
      {
         setFont();
      }   
   }

   //*****************************************************************
   //  Represents the listener for the font slider.
   //*****************************************************************   
   private class SliderListener implements ChangeListener
   {
      //--------------------------------------------------------------
      //  Updates the size of the quote font as the slider is moved.
      //--------------------------------------------------------------
      public void stateChanged (ChangeEvent event)
      {
         setFont();
      }
   }
   
   //*****************************************************************
   //  Represents the listener for all radio buttons.
   //*****************************************************************
   private class QuoteListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Sets the text of the label depending on which radio
      //  button was pressed.
      //--------------------------------------------------------------
      public void actionPerformed (ActionEvent event)
      {
         Object source = event.getSource();

         if (source == comedy)
            quote.setText (comedyQuote);
         else
            if (source == philosophy)
               quote.setText (philosophyQuote);
            else
               quote.setText (carpentryQuote);
      }
   }
}
