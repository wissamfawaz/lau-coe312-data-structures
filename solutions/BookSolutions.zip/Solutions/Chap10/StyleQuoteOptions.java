//********************************************************************
//  StyleQuoteOptions.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.8 
//********************************************************************

import javax.swing.*;

public class StyleQuoteOptions
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Style Quote Options");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add (new StyleQuoteOptionsPanel());
      frame.pack();
      frame.setVisible(true);
   }
}
