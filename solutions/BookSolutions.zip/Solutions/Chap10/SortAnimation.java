//********************************************************************
//  SortAnimation.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.6 
//********************************************************************

import javax.swing.JFrame;

public class SortAnimation
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Selection Sort Animation");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add (new SortAnimationPanel());
      frame.pack();
      frame.setVisible(true);
   }
}