//********************************************************************
//  Dog.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.3 
//********************************************************************

public class Dog implements Speaker
{
   private String name;

   //-----------------------------------------------------------------
   //  Constructor: sets this dog's name.
   //-----------------------------------------------------------------
   public Dog (String nameInit)
   {
      name = nameInit;
   }

   //-----------------------------------------------------------------
   //  Prints a specific string.
   //-----------------------------------------------------------------
   public void speak()
   {
      System.out.println (name + " says: \"Woof\"");
   }

   //-----------------------------------------------------------------
   //  Prints the specified string.
   //-----------------------------------------------------------------
   public void announce (String str)
   {
      System.out.println (name + " announces: \"" + str + "\"");
   }
}
