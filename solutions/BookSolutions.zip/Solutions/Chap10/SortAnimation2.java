//********************************************************************
//  SortAnimation2.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.7 
//********************************************************************

import javax.swing.JFrame;

public class SortAnimation2
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Insertion Sort Animation");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add (new SortAnimationPanel2());
      frame.pack();
      frame.setVisible(true);
   }
}