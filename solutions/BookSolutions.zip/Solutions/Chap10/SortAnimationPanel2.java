//********************************************************************
//  SortAnimationPanel2.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.7
//********************************************************************

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.Random;

public class SortAnimationPanel2 extends JPanel
{
   private Timer timer;
   private SteppedSort2 sortEngine;
   private final int DELAY = 200, NUM = 50, MAX = 85;

   //--------------------------------------------------------------
   //  Sets up this animation panel.
   //--------------------------------------------------------------
   public SortAnimationPanel2()
   {
      int[] numbers = new int[NUM];
      Random gen = new Random();

      for (int i=0; i < NUM; i++)
         numbers[i] = gen.nextInt(MAX) + 16;

      sortEngine = new SteppedSort2(numbers);

      timer = new Timer(DELAY, null);
      timer.addActionListener(new ReboundListener());
      timer.start();

      setBackground(Color.white);
      setPreferredSize(new Dimension(500, 200));
   }

   //--------------------------------------------------------------
   //  Paints the current state of the sort.
   //--------------------------------------------------------------
   public void paintComponent(Graphics page)
   {
      super.paintComponent(page);
      sortEngine.draw(page, getWidth(), getHeight());
   }

   //*****************************************************************
   //  Represents the action listener for the timer.
   //*****************************************************************
   private class ReboundListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Performs one step in the sort and updates the display.
      //--------------------------------------------------------------
      public void actionPerformed (ActionEvent event)
      {
         if (sortEngine.sortFinished())
            timer.stop();
         else
            sortEngine.nextStep();

         repaint();
      }
   }
}