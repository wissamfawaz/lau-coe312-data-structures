//********************************************************************
//  Philosopher.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 10.3
//********************************************************************

public class Philosopher implements Speaker
{
   private String name, quote;

   //-----------------------------------------------------------------
   //  Constructor: Sets up this philosopher with the specified data.
   //-----------------------------------------------------------------
   public Philosopher (String nameInit, String quoteInit)
   {
      name = nameInit;
      quote = quoteInit;
   }

   //-----------------------------------------------------------------
   //  Prints the stored quotation.
   //-----------------------------------------------------------------
   public void speak()
   {
      System.out.println (name + " says: \"" + quote + "\"");
   }

   //-----------------------------------------------------------------
   //  Prints the specified string.
   //-----------------------------------------------------------------
   public void announce (String str)
   {
      System.out.println (name + " announces: \"" + str + "\"");
   }

   //-----------------------------------------------------------------
   //  Prints a specific string. This method is not part of the
   //  Speaker interface.
   //-----------------------------------------------------------------
   public void pontificate()
   {
      System.out.println (name + " pontificates: \"Life is like a "
         + "box of chocolates.\"");
   }
}
