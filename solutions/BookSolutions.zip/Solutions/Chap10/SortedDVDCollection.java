//********************************************************************
//  SortedDVDCollection.java       Author: Lewis/Loftus
//
//  Solution for Programming Project 10.5
//********************************************************************

import java.text.NumberFormat;

public class SortedDVDCollection
{
   private SortableDVD[] collection;
   private int count;
   private double totalCost;

   //-----------------------------------------------------------------
   //  Constructor: Creates an initially empty collection.
   //-----------------------------------------------------------------
   public SortedDVDCollection ()
   {
      collection = new SortableDVD[100];
      count = 0;
      totalCost = 0.0;
   }

   //-----------------------------------------------------------------
   //  Adds a DVD to the collection, increasing the size of the
   //  collection array if necessary.
   //-----------------------------------------------------------------
   public void addDVD (String title, String director, int year,
      double cost, boolean bluRay)
   {
      if (count == collection.length)
         increaseSize();

      collection[count] = new SortableDVD (title, director, year, cost, bluRay);
      totalCost += cost;
      count++;
   }

   //-----------------------------------------------------------------
   //  Returns a report describing the DVD collection, presented in
   //  sorted order.
   //-----------------------------------------------------------------
   public String toString()
   {
      sortDVDs();

      NumberFormat fmt = NumberFormat.getCurrencyInstance();

      String report = "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
      report += "My DVD Collection\n\n";

      report += "Number of DVDs: " + count + "\n";
      report += "Total cost: " + fmt.format(totalCost) + "\n";
      report += "Average cost: " + fmt.format(totalCost/count);

      report += "\n\nDVD List:\n\n";

      for (int dvd = 0; dvd < count; dvd++)
         report += collection[dvd].toString() + "\n";

      return report;
   }

   //-----------------------------------------------------------------
   //  Increases the capacity of the collection by creating a
   //  larger array and copying the existing collection into it.
   //-----------------------------------------------------------------
   private void increaseSize ()
   {
      SortableDVD[] temp = new SortableDVD[collection.length * 2];

      for (int dvd = 0; dvd < collection.length; dvd++)
         temp[dvd] = collection[dvd];

      collection = temp;
   }

   //-----------------------------------------------------------------
   //  The sorting methods assume a full array. This method copies
   //  the SortableDVD array into a temporary array of the exact
   //  size, sorts them, then copies them back.
   //-----------------------------------------------------------------
   private void sortDVDs()
   {
      SortableDVD[] temp = new SortableDVD[count];
      for (int copy = 0; copy < count; copy++)
         temp [copy] = collection [copy];

      Sorting.insertionSort (temp);

      for (int copy = 0; copy < count; copy++)
         collection[copy] = temp[copy];
   }
}
