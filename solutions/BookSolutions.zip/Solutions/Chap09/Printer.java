//********************************************************************
//  Printer.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.12 
//********************************************************************

public class Printer extends HomeAppliance
{
   protected int dotsPerInch;
   protected boolean paperLoaded;
   protected boolean inkLoaded;

   //----------------------------------------------------------------
   //  Sets up a printer with the specified information.
   //----------------------------------------------------------------
   public Printer(String eManufacturer, double ePrice, double eWeight,
					int dpi, boolean paper, boolean ink)
   {
      super (eManufacturer, ePrice, eWeight);
      dotsPerInch = dpi;
      paperLoaded = paper;
      inkLoaded = ink;
   }

   //----------------------------------------------------------------
   //  Returns information about the room of the house the printer
   //  is in.
   //----------------------------------------------------------------
   public String room()
   {
      return "Office";
   }

   //----------------------------------------------------------------
   //  Checks the status of the printer.  Returns true the printer
   //  is able to print.
   //----------------------------------------------------------------
   public boolean printerStatus()
   {
      boolean result = paperLoaded && inkLoaded;
      return result;
   }

   //----------------------------------------------------------------
   //  Loads paper into the printer.
   //----------------------------------------------------------------
   public void loadPaper()
   {
      paperLoaded = true;
   }

   //----------------------------------------------------------------
   //  Loads ink into the printer.
   //----------------------------------------------------------------
   public void loadInk()
   {
      inkLoaded = true;
   }

   //----------------------------------------------------------------
   //  Returns information about this printer as a string.
   //----------------------------------------------------------------
   public String toString()
   {
      String result = super.toString();
      result += "\nDots per inch: " + dotsPerInch + "\n";
      result += "Paper loaded: " + paperLoaded + "\n";
      result += "Ink loaded: " + inkLoaded + "\n";
      result += "In Room: " + room();
      return result;
   }
}
