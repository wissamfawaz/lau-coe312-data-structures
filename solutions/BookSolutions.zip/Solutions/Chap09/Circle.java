//******************************************************************************
//  Circle.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.11 
//******************************************************************************

import java.text.*;

public class Circle extends Shape
{
   protected double radius;
   protected static DecimalFormat form = new DecimalFormat("0.##");

   //---------------------------------------------------------------------------
   //  Sets up the circle by entering its radius.
   //---------------------------------------------------------------------------
   public Circle(double rad) 
   {
      radius = rad;
   }

   //---------------------------------------------------------------------------
   //  Returns the double value of the radius.
   //---------------------------------------------------------------------------
   public double getRadius() 
   {
      return radius;
   }

   //---------------------------------------------------------------------------
   //  Returns the calculated value of the area.
   //---------------------------------------------------------------------------
   public double computeArea() 
   {
      return radius * radius * Math.PI;
   }

   //---------------------------------------------------------------------------
   //  Returns the calculated value of the perimeter (circumference).
   //---------------------------------------------------------------------------
   public double computePerimeter() 
   {
      return 2 * radius * Math.PI;
   }

   //---------------------------------------------------------------------------
   //  Returns pertinent information about the circle.
   //---------------------------------------------------------------------------
   public String toString() 
   {
      return "Circle: radius is " + form.format(radius) +
             "\ncircumference is " + form.format(computePerimeter()) +
             ", area is " + form.format(computeArea()); 
   }
}
