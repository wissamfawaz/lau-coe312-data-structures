//********************************************************************
//  AlarmClock.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.12 
//********************************************************************

public class AlarmClock extends Clock
{
   protected String alarmTime;

   //----------------------------------------------------------------
   //  Sets up an alarm clock with the specified information.
   //----------------------------------------------------------------
   public AlarmClock (String eManufacturer, double ePrice, double eWeight,
					 String time, String aTime)
   {
      super (eManufacturer, ePrice, eWeight, time);
      alarmTime = aTime;
   }

   //----------------------------------------------------------------
   //  Returns information about the room of the house the wall
   //  clock is in.
   //----------------------------------------------------------------
   public String room()
   {
      return "Bedroom";
   }

   //----------------------------------------------------------------
   //  Sets the alarm time of the alarm clock.
   //----------------------------------------------------------------
   public void setAlarm(String aTime)
   {
      alarmTime = aTime;
   }

   //----------------------------------------------------------------
   //  Returns information about this wall clock as a string.
   //----------------------------------------------------------------
   public String toString()
   {
      String result = super.toString();
      result += "\nAlarm Time: " + alarmTime + "\n";
      return result;
   }
}