//********************************************************************
//  StopWatch.java       Authors: Lewis/Loftus
//
//  Solution to Programming Project 9.10 
//********************************************************************

import javax.swing.JFrame;

public class StopWatch
{
    //-----------------------------------------------------------------
    //  Creates and presents the StopWatch frame.
    //-----------------------------------------------------------------
    public static void main(String[] args)
    {
	   JFrame frame = new JFrame ("Stop Watch");
	   frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	   frame.getContentPane().add (new StopWatchPanel());
	   frame.pack();
	   frame.setVisible (true);
    }
}
