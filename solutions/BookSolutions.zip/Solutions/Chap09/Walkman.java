//********************************************************************
//  Walkman.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.12 
//********************************************************************

public class Walkman extends PortableElectronics
{
   protected double radioFrequency;
   protected String currentTape;

   //----------------------------------------------------------------
   //  Sets up a walkman with the specified information.
   //----------------------------------------------------------------
   public Walkman (String eManufacturer, double ePrice, double eWeight,
					 double frequency, String tape)
   {
      super (eManufacturer, ePrice, eWeight);
      radioFrequency = frequency;
      currentTape = tape;
   }

   //----------------------------------------------------------------
   //  Returns information about this walkman's battery type as a
   //  string.
   //----------------------------------------------------------------
   public String batteryType()
   {
      return "AA";
   }
	
   //----------------------------------------------------------------
   //  Sets the frequency of the walkman's radio.
   //----------------------------------------------------------------
   public void setFrequency (double newFrequency)
   {
      radioFrequency = newFrequency;
   }

   //----------------------------------------------------------------
   //  Changes the current tape in the walkman.
   //----------------------------------------------------------------
   public void setTape (String newTape)
   {
      currentTape = newTape;
   }

   //----------------------------------------------------------------
   //  Returns information about this walkman as a string.
   //----------------------------------------------------------------
   public String toString()
   {
      String result = super.toString();
      result += "\nRadio Frequency: " + radioFrequency + "\n";
      result += "Current Tape: " + currentTape + "\n";
      result += "Battery Type: " + batteryType();
      return result;
   }
}