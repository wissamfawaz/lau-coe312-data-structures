//********************************************************************
//  ForeignStudent.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.5 
//********************************************************************

public class ForeignStudent extends Student
{
   private String nationality;

   //------------------------------------------------------------------
   //  Creates a foreign student with the specified data.
   //------------------------------------------------------------------
   public ForeignStudent(int personAge, String personLocation,
                  String personUniversity, String personNationality)
   {
      super(personAge, personLocation, personUniversity);
      nationality = personNationality;
   }

   //------------------------------------------------------------------
   //  Returns a string summary of this student.
   //------------------------------------------------------------------
   public String toString()
   {
      return super.toString() + "\nNationality: " + nationality;
   }
}