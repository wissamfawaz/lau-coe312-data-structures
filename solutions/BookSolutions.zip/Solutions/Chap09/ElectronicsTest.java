//********************************************************************
//  ElectronicsTest.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.12 
//********************************************************************

public class ElectronicsTest
{
   //-----------------------------------------------------------------
   //  Creates and exercises a group of objects representing
   //  electronic devices.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      Walkman walkman = new Walkman ("Panasonic", 35.48, 1.5, 97.9,
									"The Eagles - Greatest Hits");
      CellPhone cell = new CellPhone ("Motorola", 99.99, .5, 
									"555-987-1829", true);
      Printer printer = new Printer ("HP", 145.87, 8.0, 1080, false,
									false);
      Clock clock = new Clock ("Centurian", 20.34, 3.2, "12:35pm");
      AlarmClock aClock = new AlarmClock ("Timex", 18.99, 2.3, "1:37pm", 
									"6:35am");
      WallClock wClock = new WallClock ("Swiss", 13.89, 2.5, "2:33pm");

      System.out.println ("Walkman\n");
      walkman.setFrequency (104.3);
      walkman.setTape ("U2 - The Joshua Tree");
      System.out.println (walkman.toString() + "\n");

      System.out.println ("Cell Phone\n");
      System.out.println (cell.toString());
      if (cell.takesPictures())
         System.out.println ("This is a camera phone.\n");
      else
         System.out.println ("Sorry, your phone cannot take pictures.\n");

      System.out.println ("Printer\n");
      System.out.println (printer.toString());
      if (printer.printerStatus())
         System.out.println ("This printer is ready to print.\n");
      else
         System.out.println ("Printer not ready. Load ink and paper.\n");

      System.out.println ("Clock\n");
      System.out.println (clock.toString() + "\n");

      System.out.println ("Wall Clock\n");
      System.out.println ("Current time: " + wClock.getTime());
      System.out.println ("New time will be set to 3:45pm.");
      wClock.setTime("3:45pm");
      System.out.println (wClock.toString() + "\n");

      System.out.println ("Alarm Clock\n");
      System.out.println ("Current time: " + aClock.getTime());
      System.out.println ("New time will match wall clock.");
      aClock.setTime(wClock.getTime());
      System.out.println (aClock.toString() + "\n");
   }
}