//******************************************************************************
//  Shape.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.11 
//******************************************************************************

public abstract class Shape
{
   abstract public double computeArea();
   abstract public double computePerimeter();
}
