//******************************************************************************
//  Sphere.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.11 
//******************************************************************************

public class Sphere extends Circle
{
   //---------------------------------------------------------------------------
   //  Sets up the sphere by entering its radius.
   //---------------------------------------------------------------------------
   public Sphere (double rad)
   {
      super(rad);
   }

   //---------------------------------------------------------------------------
   //  Returns the calculated value of the surface area.
   //---------------------------------------------------------------------------
   public double computeArea() 
   {
      return 4 * super.computeArea();
   }

   //---------------------------------------------------------------------------
   //  Returns the calculated value of the volume.
   //---------------------------------------------------------------------------
   public double computeVolume() 
   {
      return Math.pow(radius, 3) * Math.PI * 4 / 3;
   }

   //---------------------------------------------------------------------------
   //  Returns pertinent information about the sphere.
   //---------------------------------------------------------------------------
   public String toString() 
   {
      return "Sphere: radius is " + form.format(radius) +
             "\ncircumference is " + form.format(computePerimeter()) +
             ", area is " + form.format(computeArea()) +
             "\nvolume is " + form.format(computeVolume()) + "\n"; 
   }
}