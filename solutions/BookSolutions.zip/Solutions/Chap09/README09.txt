This folder contains solutions to the Programming Projects from
Chapter 9 of Java Software Solutions, 7th Edition, by Lewis and Loftus.

Project     File(s)
-------     -------

9.1         MonetaryCoinDriver.java
            Coin.java
            MonetaryCoin.java

9.2         Hospital.java
            HosptialEmployee.java
            Doctor.java
            Surgeon.java
            Nurse.java
            Administrator.java
            Janitor.java
            Receptionist.java

9.3         ReadingClub.java
            ReadingMaterial.java
            Book.java
            Novel.java
            TextBook.java
            Magazine.java

9.4         Players.java
            PlayerStats.java
            BaseballStats.java
            FootballStats.java

9.5         Demographics.java
            Person.java
            Worker.java
            Student.java
            ForeignStudent.java

9.6         Rebound2.java
            ReboundPanel2.java
            happyFace.gif

9.7         Drive.java
            DrivePanel.java
            Car2.java

9.8         LineCross.java
            LineCrossPanel.java

9.9         CatchTheCreature.java
            CatchTheCreaturePanel.java
            Creature.java
            creature.gif

9.10        StopWatch.java
            StopWatchPanel.java

9.11        ShapeTester.java
            Shape.java
            Circle.java
            Cylinder.java
            Sphere.java
            Rectangle.java
            Pentahedron.java
            Prism.java
            Triangle.java
            Tetrahedron.java
            shapes.dat

9.12        ElectronicsTest.java
            Electronics.java
            HomeAppliance.java
            Clock.java
            AlarmClock.java
            WallClock.java
            Printer.java
            PortableElectronics.java
            Walkman.java
            CellPhone.java

9.13        CourseTester.java
            Schedule.java
            Course.java
            Elective.java
            GeneralEducation.java
            MajorCourse.java


