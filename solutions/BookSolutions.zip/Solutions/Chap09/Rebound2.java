//********************************************************************
//  Rebound2.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.6
//********************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Rebound2
{
   //-----------------------------------------------------------------
   //  Displays the main frame of the program.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Rebound");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add(new ReboundPanel2());
      frame.pack();
      frame.setVisible(true);
   }
}
