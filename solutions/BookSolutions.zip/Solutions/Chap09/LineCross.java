//********************************************************************
//  LineCross.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.8 
//********************************************************************

import javax.swing.JFrame;

public class LineCross
{
   //-----------------------------------------------------------------
   //  Displays the main frame of the program.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Line Cross");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add(new LineCrossPanel());
      frame.pack();
      frame.setVisible(true);
   }
}
