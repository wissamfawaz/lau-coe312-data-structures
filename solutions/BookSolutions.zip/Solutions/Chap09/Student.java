//********************************************************************
//  Student.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.5 
//********************************************************************

public class Student extends Person
{
   private String university;

   //------------------------------------------------------------------
   //  Creates a student with the specified data.
   //------------------------------------------------------------------
   public Student(int personAge, String personLocation, String personUniversity)
   {
      super(personAge, personLocation);
      university = personUniversity;
   }

   //------------------------------------------------------------------
   //  Returns a string summary of this student.
   //------------------------------------------------------------------
   public String toString()
   {
      return super.toString() + "\nUniversity: " + university;
   }
}