//********************************************************************
//  Car2.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.7 
//********************************************************************

import java.awt.*;

class Car2
{
   // Coordinates if car is drawn at position 0,0
   private int[] x = {  0,   0,  20,  25,  70,  80, 105, 110 };
   private int[] y = { 35,  15,  15,   0,   0,  15,  15,  35 };

   private int[] xCurrent = new int [x.length];
   private int[] yCurrent = new int [y.length];

   private int xOffset, yOffset;
   private Color carColor;
   private Polygon body;

   //-----------------------------------------------------------------
   //  Sets up the graphical car with the specified information.
   //-----------------------------------------------------------------
   public Car2 (int xOff, int yOff, Color color)
   {
      xOffset = xOff;
      yOffset = yOff;
      carColor = color;

      for (int scan = 0; scan < x.length; scan++)
      {
         xCurrent[scan] = x[scan] + xOffset;
         yCurrent[scan] = y[scan] + yOffset;
      }

      body = new Polygon (xCurrent, yCurrent, x.length);
   }

   //-----------------------------------------------------------------
   //  Draws the car at a particular x and y offset.
   //-----------------------------------------------------------------
   public void draw (Graphics page)
   {
      page.setColor (Color.black);
      page.fillOval (13+xOffset, 28+yOffset, 14, 14);  // rear wheel
      page.fillOval (83+xOffset, 28+yOffset, 14, 14);  // front wheel
      page.drawLine (15+xOffset, 18+yOffset, 15+xOffset, 3+yOffset);

      page.setColor (carColor);
      page.fillPolygon (body);
   }

   //-----------------------------------------------------------------
   //  Resets the car's position so that it can "move" in animation.
   //-----------------------------------------------------------------
   public void setPosition (int newX, int newY)
   {
      body.translate (newX - xOffset, newY - yOffset);
      xOffset = newX;
      yOffset = newY;
   }
}
