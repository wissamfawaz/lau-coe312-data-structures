//********************************************************************
//  DrivePanel.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.7 
//********************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DrivePanel extends JPanel
{
   private Car2 car;

   private Timer animate;
   private int xOff = 20;

   private static final int DELAY = 30;
   private static final int INITIAL_X = 20,
                            INITIAL_Y = 50,
                            RESTART_POS = -100;

   //-----------------------------------------------------------------
   //  Sets up the panel.
   //-----------------------------------------------------------------
   public DrivePanel()
   {
      car = new Car2 (INITIAL_X, INITIAL_Y, Color.red);
      setBackground (Color.white);
      setPreferredSize (new Dimension(500, 200));
      animate = new Timer (DELAY, new Animator());
      animate.start();
   }

   //-----------------------------------------------------------------
   //  Draws the car in its current position.
   //-----------------------------------------------------------------
   public void paintComponent (Graphics page)
   {
      super.paintComponent(page);
      car.draw (page);
   }

   //*****************************************************************
   //  Inner class that listens for the timer to move the car and
   //  repaint the screen during the animation.
   //*****************************************************************
   private class Animator implements ActionListener
   {
      public void actionPerformed (ActionEvent event)
      {
         xOff += 3;
         if (xOff > getWidth())
            xOff = RESTART_POS;
         car.setPosition (xOff, 50);
         repaint ();
      }
   }
}
