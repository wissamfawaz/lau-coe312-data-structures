//********************************************************************
//  LineCrossPanel.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.8 
//********************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LineCrossPanel extends JPanel
{
   private final int DELAY = 20;
   private final int SHIFT = 1;
   private final int LENGTH = 80;

   private int x, y, crossPoint;
   private Timer timer;

   //-----------------------------------------------------------------
   //  Sets up the panel.
   //-----------------------------------------------------------------
   public LineCrossPanel()
   {
      x = 0;
      y = 100;
      crossPoint = (int) (Math.random() * 100) + 50;

      setBackground (Color.black);
      setPreferredSize (new Dimension(300, 300));

      timer = new Timer(DELAY, new LineCrossActionListener());
      timer.start();
   }

   //-----------------------------------------------------------------
   //  Draws the line in the current location.
   //-----------------------------------------------------------------
   public void paintComponent (Graphics page)
   {
      super.paintComponent (page);

      page.setColor (Color.red);
      page.drawLine (crossPoint, 0, crossPoint, getHeight());

      if (x+LENGTH < crossPoint)
      {
         page.setColor (Color.magenta);
         page.drawLine (x, y, x+LENGTH, y);
      }
      else
      {
         if(x > crossPoint)
         {
            page.setColor (Color.yellow);
            page.drawLine (x, y, x+LENGTH, y);
         }
         else
         {
            page.setColor (Color.magenta);
            page.drawLine (x, y, crossPoint, y);

            page.setColor (Color.yellow);
            page.drawLine (crossPoint, y, x+LENGTH, y);
         }

      }
   }

   //*****************************************************************
   //  Represents the action listener for the timer.
   //*****************************************************************
   private class LineCrossActionListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Updates the position of the line.
      //--------------------------------------------------------------
      public void actionPerformed (ActionEvent event)
      {
         x += SHIFT;

         if (x > getWidth())
            x = -LENGTH;

         repaint();
      }
   }
}