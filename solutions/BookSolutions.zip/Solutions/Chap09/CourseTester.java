//********************************************************************
//  CourseTester.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.13 
//********************************************************************

public class CourseTester
{
   //----------------------------------------------------------------
   //  Creates a schedule of classes and displays it.
   //----------------------------------------------------------------
   public static void main (String[] args)
   {
      Schedule fallSchedule = new Schedule();
      fallSchedule.display();
   }
}