//********************************************************************
//  StopWatchPanel.java       Authors: Lewis/Loftus
//
//  Solution to Programming Project 9.10 
//********************************************************************

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.border.*;
import java.text.*;

public class StopWatchPanel extends JPanel
{
   private DecimalFormat fmt;
   private JLabel timeDisplay;
   private Timer timer;
   private double time;

   private final String ZERO_TIME = "0.0";
   private final int DELAY = 100;
   private final String START = "Start";
   private final String STOP = "Stop";
   private final String RESET = "Reset";

   //-----------------------------------------------------------------
   //  Sets up the GUI for the stop watch.
   //-----------------------------------------------------------------
   public StopWatchPanel()
   {
      setLayout(new GridLayout(2,1));

      // initialize the time display
      time = 0.0;
      timeDisplay = new JLabel(ZERO_TIME);
      timeDisplay.setBackground(Color.white);
      timeDisplay.setHorizontalAlignment(SwingConstants.CENTER);
      timeDisplay.setFont(new Font("SAN_SERIF",Font.BOLD,24));
      timeDisplay.setBorder(new LineBorder(Color.black, 3));
      add(timeDisplay,BorderLayout.NORTH);

      fmt = new DecimalFormat("0.#");

      JPanel buttonPanel = new JPanel();

      JButton button;
      ButtonActionListener buttonPressed = new ButtonActionListener();

      button = new JButton(START);
      button.setMnemonic('S');
      button.addActionListener(buttonPressed);
      buttonPanel.add(button);

      button = new JButton(STOP);
      button.setMnemonic('p');
      button.addActionListener(buttonPressed);
      buttonPanel.add(button);

      button = new JButton(RESET);
      button.setMnemonic('R');
      button.addActionListener(buttonPressed);
      buttonPanel.add(button);

      add(buttonPanel, BorderLayout.CENTER);

      // create the timer
      timer = new Timer(DELAY, new TimerActionListener());
   }

   //-----------------------------------------------------------------
   //  Starts the stop watch.
   //-----------------------------------------------------------------
    private void startTime()
    {
       timer.start();
    }

   //-----------------------------------------------------------------
   //  Stops the stop watch.
   //-----------------------------------------------------------------
   private void stopTime()
   {
      timer.stop();
   }

   //-----------------------------------------------------------------
   //  Resets the stop watch.
   //-----------------------------------------------------------------
   private void resetTime()
   {
      timer.stop();
      timeDisplay.setText(ZERO_TIME);
      time = 0.0;
   }

   //********************************************************************
   //  Represents the action listener for the timer.
   //********************************************************************
   private class TimerActionListener implements ActionListener
   {
      //-----------------------------------------------------------------
      //  Updates the time by one-tenth second.
      //-----------------------------------------------------------------
      public void actionPerformed (ActionEvent actionEvent)
      {
         time = time + 0.1;
         timeDisplay.setText(fmt.format(time));
      }
   }

   //********************************************************************
   //  Represents the action listener for the buttons.
   //********************************************************************
   private class ButtonActionListener implements ActionListener
   {
      //-----------------------------------------------------------------
      //  determines which button was pressed and executes appropriate
      //  command.
      //-----------------------------------------------------------------
      public void actionPerformed(ActionEvent evt)
      {
         JButton source = (JButton)evt.getSource();
         String text = source.getText();
         if (text.equals(START))
            startTime();
         else
            if (text.equals(STOP))
               stopTime();
            else
               if (text.equals(RESET))
                  resetTime();
      }
   }
}
