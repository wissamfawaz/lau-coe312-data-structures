//******************************************************************************
//  Cylinder.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.11 
//******************************************************************************

public class Cylinder extends Circle
{
   private double height;

   //---------------------------------------------------------------------------
   //  Sets up the cylinder by entering the circle radius and the height.
   //---------------------------------------------------------------------------
   public Cylinder (double rad, double hei)
   {
      super(rad);
      height = hei;
   }

   //---------------------------------------------------------------------------
   //  Returns the double value of the height.
   //---------------------------------------------------------------------------
   public double getHeight() 
   {
      return height;
   }

   //---------------------------------------------------------------------------
   //  Returns the calculated value of the surface area.
   //---------------------------------------------------------------------------
   public double computeArea() 
   {
      return 2 * super.computeArea() + height * computePerimeter();
   }

   //---------------------------------------------------------------------------
   //  Returns the calculated value of the volume.
   //---------------------------------------------------------------------------
   public double computeVolume() 
   {
      return super.computeArea() * height;
   }

   //---------------------------------------------------------------------------
   //  Returns pertinent information about the cylinder.
   //---------------------------------------------------------------------------
   public String toString() 
   {
      return "Cylinder: height is " + form.format(height) +
             "\nperimeter of base is " + form.format(computePerimeter()) +
             ", area is " + form.format(computeArea()) +
             "\nvolume is " + form.format(computeVolume()) + "\n";
   }
}