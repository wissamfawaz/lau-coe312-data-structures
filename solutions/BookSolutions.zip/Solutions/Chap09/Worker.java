//********************************************************************
//  Worker.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 9.5 
//********************************************************************

import java.text.NumberFormat;

public class Worker extends Person
{
   private String occupation;
   private int income;

   //------------------------------------------------------------------
   //  Creates an employee with the specified data.
   //------------------------------------------------------------------
   public Worker (int personAge, String personLocation,
                  String personOccupation, int personIncome)
   {
      super( personAge, personLocation);
      occupation = personOccupation;
      income = personIncome;
   }

   //------------------------------------------------------------------
   //  Returns a string summary of this Worker.
   //------------------------------------------------------------------
   public String toString()
   {
      return super.toString() + "\nOccupation: " + occupation
               + "\nIncome: "
               + NumberFormat.getCurrencyInstance().format(income);
   }
}