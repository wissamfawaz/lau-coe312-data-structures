//********************************************************************
//  Equation.java       Authors: Lewis/Loftus
//
//  Solution to Programming Project 11.9 
//********************************************************************

public class Equation
{
   private int firstNumber;
   private int secondNumber;
   private int equationType;

   public static final int ADDITION = 0;
   public static final int SUBTRACTION = 1;
   public static final int MULTIPLICATION = 2;
   public static final int DIVISION  = 3;
   public static final String DIVISION_SIGN = "\u00F7";
   public static final String[] EQUATION_TYPES = {
                        "Addition",
                        "Subtraction",
                        "Multiplication",
                        "Division" };

   //-----------------------------------------------------------------
   //  Setters and getters.
   //-----------------------------------------------------------------
   void setFirstNumber(int num)
   {
      firstNumber = num;
   }

   public int getFirstNumber()
   {
      return firstNumber;
   }

   void setSecondNumber(int num)
   {
      secondNumber = num;
   }

   public int getSecondNumber()
   {
      return secondNumber;
   }

   void setEquationType(int type)
   {
      equationType = type;
   }

   public int getEquationType()
   {
      return equationType;
   }

   public String getEquationTypeString()
   {
      switch (equationType)
      {
         case ADDITION:
            return "+";
         case SUBTRACTION:
            return "-";
         case MULTIPLICATION:
            return "x";
         case DIVISION:
            return DIVISION_SIGN;
         default:
            return "ERR";
      }
   }

   //-----------------------------------------------------------------
   //  Returns a string representation of this equation.
   //-----------------------------------------------------------------
   public String toString()
   {
      return firstNumber + " " + getEquationTypeString() + " "
               + secondNumber + " = " + getSolution();
   }

   //-----------------------------------------------------------------
   //  Returns the solution to the equation. If there is an error,
   //  such as division by zero, or improper equation, returns -1.
   //-----------------------------------------------------------------
   public int getSolution()
   {
      int solution;

      switch (equationType)
      {
         case ADDITION:
            solution = firstNumber + secondNumber;
            break;
         case SUBTRACTION:
            solution = firstNumber - secondNumber;
            break;
         case MULTIPLICATION:
            solution = firstNumber * secondNumber;
            break;
         case DIVISION:
            if (secondNumber == 0)  // division by zero
               return -1;
            solution = firstNumber / secondNumber;
            break;
         default:
            solution = -1;
      }

      if (solution < 0)
         solution = -1;

      return solution;
   }
}
