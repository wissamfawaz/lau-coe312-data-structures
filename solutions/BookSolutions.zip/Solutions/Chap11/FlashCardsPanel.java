//********************************************************************
//  FlashCardsPanel.java       Authors: Lewis/Loftus
//
//  Solution to Programming Project 11.9
//********************************************************************

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class FlashCardsPanel extends JPanel
{
   private JLabel firstNumberLabel;
   private JLabel equationLabel;
   private JLabel secondNumberLabel;
   private JTextField answerTextField;
   private JComboBox equationTypeComboBox;
   private JLabel scoreLabel;
   private JTextField commentTextField;

   private EquationGenerator eqGen;
   private Equation currentEquation;
   private int currentEquationType;
   private int numCorrect;
   private int totalEquations;
   private boolean countProblem;

   private final String START_STRING = "Enter your answer";
   private final String CORRECT_STRING = "Good job!";
   private final String REVEAL_STRING = "The correct answer is ";
   private final String GIVE_UP_STRING = "Give up?  Try another";
   private final String DONT_COUNT = "Let's try some ";

   //-----------------------------------------------------------------
   //  Sets up the flash cards GUI.
   //-----------------------------------------------------------------
   public FlashCardsPanel()
   {
      numCorrect = totalEquations = 0;
      countProblem = true;
      currentEquationType = Equation.ADDITION;
      eqGen = new EquationGenerator();
      currentEquation = eqGen.generateAdditionEquation();

      setLayout (new BorderLayout());
      add (setUpEquationPanel(), BorderLayout.CENTER);
      add (setUpInfoPanel(), BorderLayout.NORTH);
      add (setUpLowerPanel(), BorderLayout.SOUTH);

      updateScore();
      displayEquation();
      answerTextField.requestFocus();

      setPreferredSize(new Dimension(300,340));
   }

   //-----------------------------------------------------------------
   //  Sets up the lower panel in the GUI.
   //-----------------------------------------------------------------
   private JPanel setUpLowerPanel()
   {
      JPanel lowerPanel = new JPanel();
      lowerPanel.setLayout(new GridLayout(2, 1));

      JButton nextButton = new JButton("Next");
      nextButton.setMnemonic('N');
      nextButton.addActionListener(new NewEquationListener());

      lowerPanel.add(nextButton);

      commentTextField = new JTextField(START_STRING);
      lowerPanel.add(commentTextField);

      return lowerPanel;
   }

   //-----------------------------------------------------------------
   //  Sets up the info panel in the GUI.
   //-----------------------------------------------------------------
   private JPanel setUpInfoPanel()
   {
      JPanel infoPanel = new JPanel();
      infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));

      JPanel typePanel = new JPanel();
      typePanel.add(new JLabel("Equation type: "));

      equationTypeComboBox = new JComboBox(Equation.EQUATION_TYPES);
      equationTypeComboBox.addActionListener(new EquationTypeListener());

      typePanel.add(equationTypeComboBox);

      infoPanel.add(typePanel);

      JPanel scorePanel = new JPanel();
      scorePanel.setBorder(new LineBorder(Color.blue));
      scorePanel.add(new JLabel("  Score: "));

      scoreLabel = new JLabel("  0 / 0     ");
      scoreLabel.setFont(new java.awt.Font("Dialog", 0, 18));
      scoreLabel.setBorder(new EtchedBorder(EtchedBorder.RAISED));
      scorePanel.add(scoreLabel);

      JButton resetButton = new JButton("Reset Score");
      resetButton.setMnemonic('R');
      resetButton.addActionListener(new ResetListener());

      scorePanel.add(resetButton);

      infoPanel.add(scorePanel);

      return infoPanel;
   }

   //-----------------------------------------------------------------
   //  Sets up the main equation panel in the GUI.
   //-----------------------------------------------------------------
   private JPanel setUpEquationPanel()
   {
      JPanel equationPanel = new JPanel();
      equationPanel.setLayout(new GridLayout(3, 3));

      equationPanel.add(new JLabel()); // blank label

      Font equationFont = new Font("Dialog", Font.PLAIN, 36);

      firstNumberLabel = new JLabel();
      firstNumberLabel.setFont(equationFont);
      firstNumberLabel.setHorizontalAlignment(SwingConstants.CENTER);
      equationPanel.add(firstNumberLabel);

      equationPanel.add(new JLabel());  // blank label

      equationLabel = new JLabel();
      equationLabel.setFont(equationFont);
      equationLabel.setHorizontalAlignment(SwingConstants.RIGHT);
      equationPanel.add(equationLabel);

      secondNumberLabel = new JLabel();
      secondNumberLabel.setFont(equationFont);
      secondNumberLabel.setHorizontalAlignment(SwingConstants.CENTER);
      equationPanel.add(secondNumberLabel);

      equationPanel.add(new JLabel());  // blank label

      equationPanel.add(new JLabel("Answer: "));

      answerTextField = new JTextField();
      answerTextField.setFont(equationFont);
      answerTextField.setHorizontalAlignment(JTextField.CENTER);
      answerTextField.addActionListener(new NewEquationListener());

      equationPanel.add(answerTextField);

      return equationPanel;
   }

   //-----------------------------------------------------------------
   //  Updates the current score.
   //-----------------------------------------------------------------
   private void updateScore()
   {
      scoreLabel.setText("  " + numCorrect + " / " + totalEquations + "  ");
   }

   //-----------------------------------------------------------------
   //  Determines if a correct answer was given, updates score, and
   //  based on the current equation type, displays a new equation.
   //-----------------------------------------------------------------
   private void newEquation()
   {
      if (countProblem)
      {
         totalEquations++;
         if (answerCorrect())
         {
            commentTextField.setText(CORRECT_STRING);
            numCorrect++;
         }
         else
            commentTextField.setText(REVEAL_STRING + currentEquation);

         updateScore();
      }
      else
      {
         countProblem = true;
         commentTextField.setText(DONT_COUNT + Equation.EQUATION_TYPES[currentEquationType]);
      }

      switch (currentEquationType)
      {
         case Equation.ADDITION:
            currentEquation = eqGen.generateAdditionEquation();
            break;
         case Equation.SUBTRACTION:
            currentEquation = eqGen.generateSubtractionEquation();
            break;
         case Equation.MULTIPLICATION:
            currentEquation = eqGen.generateMultiplicationEquation();
            break;
         case Equation.DIVISION:
            currentEquation = eqGen.generateDivisionEquation();
            break;
         default:
      }

      displayEquation();
      answerTextField.requestFocus();
   }

   //-----------------------------------------------------------------
   //  Displays the current equation in the GUI.
   //-----------------------------------------------------------------
   private void displayEquation()
   {
      firstNumberLabel.setText(String.valueOf(currentEquation.getFirstNumber()));
      secondNumberLabel.setText(String.valueOf(currentEquation.getSecondNumber()));
      equationLabel.setText(currentEquation.getEquationTypeString());
      answerTextField.setText("");
   }

   //-----------------------------------------------------------------
   //  Determines if a user has given the correct answer.
   //-----------------------------------------------------------------
   private boolean answerCorrect()
   {
      try
      {
         int answer = Integer.parseInt(answerTextField.getText());
         if (answer == currentEquation.getSolution())
            return true;
         else
            return false;
      }
      catch (NumberFormatException e)
      {
         return false;
      }
   }

   //*****************************************************************
   //  Represents the listener for reset button.
   //*****************************************************************
   private class ResetListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Resets the number correct and updates the score.
      //--------------------------------------------------------------
      public void actionPerformed (ActionEvent event)
      {
         numCorrect = totalEquations = 0;
         updateScore();
      }
   }

   //*****************************************************************
   //  Represents the listener for equation type combo box.
   //*****************************************************************
   private class EquationTypeListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Sets the equation type.
      //--------------------------------------------------------------
      public void actionPerformed (ActionEvent event)
      {
         int newEquationType = equationTypeComboBox.getSelectedIndex();
         if (newEquationType != currentEquationType)
         {
            currentEquationType = newEquationType;
            countProblem = false;
            newEquation();
         }
         else
            currentEquationType = newEquationType;
      }
   }

   //*****************************************************************
   //  Represents the listener for next button and answer field.
   //*****************************************************************
   private class NewEquationListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Processes answer and sets up the next equation.
      //--------------------------------------------------------------
      public void actionPerformed (ActionEvent event)
      {
         newEquation();
      }
   }
}

