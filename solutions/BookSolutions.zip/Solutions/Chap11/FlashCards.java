//********************************************************************
//  FlashCards.java       Authors: Lewis/Loftus
//
//  Solution to Programming Project 11.9 
//********************************************************************

import java.awt.*;
import javax.swing.*;

public class FlashCards
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Flash Cards");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add (new FlashCardsPanel());
      frame.pack();
      frame.setVisible(true);
   }
}
