//********************************************************************
//  InvalidDocumentCodeException.java       Author: Lewis/Loftus
//
//  Solution to Programming Projects 11.3 and 11.4 
//********************************************************************

public class InvalidDocumentCodeException extends Exception
{
   //-----------------------------------------------------------------
   //  Sets up the exception object with a particular message.
   //-----------------------------------------------------------------
   InvalidDocumentCodeException (String message)
   {
      super (message);
   }
}
