//********************************************************************
//  ReadStrings.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 11.1 
//********************************************************************

import java.util.Scanner;

public class ReadStrings
{
   //-----------------------------------------------------------------
   //  Creates an exception object and throws it as appropriate.
   //-----------------------------------------------------------------
   public static void main (String[] args) throws StringTooLongException
   {
      final int MAX = 20;
      String input = "";

      Scanner scan = new Scanner (System.in);

      StringTooLongException lengthException =
         new StringTooLongException ("String has too many characters");

      System.out.println("Enter strings, enter DONE when finished:");

	  do
      {
         input = scan.nextLine();
         if (!input.equals("DONE"))
            if (input.length() > MAX)
               throw lengthException;
            else
               System.out.println ("You entered: " + input);
      }
      while (!input.equals("DONE"));

      System.out.println("Program successfully completed");
   }
}
