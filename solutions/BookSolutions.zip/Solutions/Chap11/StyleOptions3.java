//********************************************************************
//  StyleOptions3.java       Author: Lewis/Loftus
//
// Solution to Programming Project 11.7 
//********************************************************************

import javax.swing.*;

public class StyleOptions3
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Style Options");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add (new StyleOptionsPanel3());
      frame.pack();
      frame.setVisible(true);
   }
}
