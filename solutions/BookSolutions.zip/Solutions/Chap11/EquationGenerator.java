//********************************************************************
//  EquationGenerator.java       Authors: Lewis/Loftus
//
//  Solution to Programming Project 11.9 
//********************************************************************

import java.util.Random;

public class EquationGenerator
{
   final int MAX_NUMBER = 11;  // use numbers between 0 and 10

   Random numberGenerator;

   //-----------------------------------------------------------------
   //  Sets up this equation generator.
   //-----------------------------------------------------------------
   public EquationGenerator()
   {
      numberGenerator = new Random();
   }

   //-----------------------------------------------------------------
   //  Returns a random addition equation.
   //-----------------------------------------------------------------
   public Equation generateAdditionEquation()
   {
      Equation eq = new Equation();
      eq.setFirstNumber(numberGenerator.nextInt(MAX_NUMBER));
      eq.setSecondNumber(numberGenerator.nextInt(MAX_NUMBER));
      eq.setEquationType(Equation.ADDITION);
      return eq;
   }

   //-----------------------------------------------------------------
   //  Returns a random subtraction equation.
   //-----------------------------------------------------------------
   public Equation generateSubtractionEquation()
   {
      Equation eq = generateAdditionEquation();
      eq.setFirstNumber(eq.getSolution());
      eq.setEquationType(Equation.SUBTRACTION);
      return eq;
   }

   //-----------------------------------------------------------------
   //  Returns a random multiplication equation.
   //-----------------------------------------------------------------
   public Equation generateMultiplicationEquation()
   {
      Equation eq = new Equation();
      eq.setFirstNumber(numberGenerator.nextInt(MAX_NUMBER));
      eq.setSecondNumber(numberGenerator.nextInt(MAX_NUMBER));
      eq.setEquationType(Equation.MULTIPLICATION);
      return eq;
   }

   //-----------------------------------------------------------------
   //  Returns a random division equation.
   //-----------------------------------------------------------------
   public Equation generateDivisionEquation()
   {
      Equation eq;
      do
      {
         eq = generateMultiplicationEquation();
      }
      while (eq.getSecondNumber() == 0);  // check for division by 0

      eq.setFirstNumber(eq.getSolution());
      eq.setEquationType(Equation.DIVISION);

      return eq;
   }
}
