//********************************************************************
//  ReadStrings2.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 11.2 
//********************************************************************

import java.util.Scanner;

public class ReadStrings2
{
   //-----------------------------------------------------------------
   //  Creates an exception object, throws it when appropriate, and
   //  catches it for processing.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      final int MAX = 20;
      String input = "";

      Scanner scan = new Scanner (System.in);

      StringTooLongException lengthException =
         new StringTooLongException ("String has too many characters");

      System.out.println("Enter strings, enter DONE when finished:");

	  do
      {
         input = scan.nextLine();
         if (!input.equals("DONE"))
            try
            {
               if (input.length() > MAX)
                  throw lengthException;
               else
                  System.out.println ("You entered: " + input);
            }
            catch (StringTooLongException e)
            {
                System.out.println(e.getMessage());
                System.out.println("Please try again:");
	        }
      }
      while (!input.equals("DONE"));

      System.out.println("Program successfully completed");
   }
}
