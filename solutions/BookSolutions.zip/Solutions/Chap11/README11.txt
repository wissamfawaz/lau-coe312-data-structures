This folder contains solutions to the Programming Projects from
Chapter 11 of Java Software Solutions, 7th Edition, by Lewis and Loftus.

Project     File(s)
-------     -------

11.1        ReadStrings.java
            StringTooLongException.java

11.2        ReadStrings2.java
            StringTooLongException.java

11.3        ReadDocumentCodes.java
            InvalidDocumentCodeException.java

11.4        ReadDocumentCodes2.java
            InvalidDocumentCodeException.java

11.5        DisplayAndSaveFile.java
            DisplayAndSaveFilePanel.java
            aquarius.dat

11.6        JukeBox2.java
            JukeBoxControls2.java
            stop.gif
            play.gif
            various *.wav and *.au audio files

11.7        StyleOptions3.java
            StyleOptionsPanel3.java

11.8        PickImage2.java 
            ListPanel2.java
            various *.jpg and *.gif image files

11.9        FlashCards.java
            FlashCardsPanel.java
            EquationGenerator.java
            Equation.java
