//********************************************************************
//  JukeBoxControls2.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 11.6 
//********************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.applet.AudioClip;
import java.net.URL;

public class JukeBoxControls2 extends JPanel
{
   private JComboBox musicCombo;
   private JButton stopButton, playButton;
   private AudioClip[] music;
   private AudioClip current;

   //-----------------------------------------------------------------
   //  Sets up the GUI for the juke box.
   //-----------------------------------------------------------------
   public JukeBoxControls2()
   {
      music = new AudioClip[7];

      // Obtain and store the audio clips to play
      try
      {
         music[0] = null;  // Corresponds to "Make a Selection..."
         music[1] = JApplet.newAudioClip (
            new URL("file", "localhost", "westernBeat.wav"));
         music[2] = JApplet.newAudioClip (
            new URL("file", "localhost", "classical.wav"));
         music[3] = JApplet.newAudioClip (
            new URL("file", "localhost", "jeopardy.au"));
         music[4] = JApplet.newAudioClip (
            new URL("file", "localhost", "newAgeRythm.wav"));
         music[5] = JApplet.newAudioClip (
            new URL("file", "localhost", "eightiesJam.wav"));
         music[6] = JApplet.newAudioClip (
            new URL("file", "localhost", "hitchcock.wav"));
      }
      catch (Exception exception) {}

      JLabel titleLabel = new JLabel ("Java Juke Box");
      titleLabel.setAlignmentX (Component.CENTER_ALIGNMENT);

      // Create the list of strings for the combo box options.
      String[] musicNames = {"Make A Selection...", "Western Beat",
               "Classical Melody", "Jeopardy Theme", "New Age Rythm",
               "Eighties Jam", "Alfred Hitchcock's Theme"};

      musicCombo = new JComboBox (musicNames);
      musicCombo.setAlignmentX (Component.CENTER_ALIGNMENT);

      playButton = new JButton ("Play", new ImageIcon ("play.gif"));
      playButton.setBackground (Color.white);
      playButton.setMnemonic ('p');
      stopButton = new JButton ("Stop", new ImageIcon ("stop.gif"));
      stopButton.setBackground (Color.white);
      stopButton.setMnemonic ('s');

      JPanel buttons = new JPanel();
      buttons.setLayout(new BoxLayout(buttons, BoxLayout.X_AXIS));
      buttons.add (playButton);
      buttons.add (Box.createRigidArea (new Dimension(5,0)));
      buttons.add (stopButton);
      buttons.setBackground (Color.cyan);

      //  Set up this panel
      setPreferredSize (new Dimension (300, 100));
      setBackground (Color.cyan);
      setLayout (new BoxLayout(this, BoxLayout.Y_AXIS));
      add (titleLabel);
      add (Box.createRigidArea (new Dimension(0,5)));
      add (musicCombo);
      add (Box.createRigidArea (new Dimension(0,5)));
      add (buttons);
      add (Box.createRigidArea (new Dimension(0,5)));

      musicCombo.addActionListener (new JukeBoxListener());
      stopButton.addActionListener (new JukeBoxListener());
      playButton.addActionListener (new JukeBoxListener());

      current = null;
   }

   //*****************************************************************
   //  A listener for various events of the juke box.
   //*****************************************************************
   private class JukeBoxListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Handles the play and stop buttons and the combo box.
      //--------------------------------------------------------------
      public void actionPerformed (ActionEvent event)
      {
         if (current != null)  // Stop current clip no matter what
            current.stop();

         Object source = event.getSource();
         if (source == playButton)
         {
            if (current != null)
               current.play();
         }
         else if (source == musicCombo)
         {
            current = music[musicCombo.getSelectedIndex()];
            if (current != null)
              current.play();
         }
      }
   }
}
