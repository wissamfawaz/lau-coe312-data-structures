//********************************************************************
//  DisplayAndSaveFilePanel.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 11.5 
//********************************************************************

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DisplayAndSaveFilePanel extends JPanel
{
   private JTextArea ta;
   private File file;

   //-----------------------------------------------------------------
   //  Opens a file chooser dialog, reads the selected file and
   //  loads it into a text area.
   //-----------------------------------------------------------------
   public DisplayAndSaveFilePanel() throws IOException
   {
      ta = new JTextArea (20, 30);
      JFileChooser chooser = new JFileChooser();

      int status = chooser.showOpenDialog (null);

      if (status != JFileChooser.APPROVE_OPTION)
         ta.setText ("No File Chosen");
      else
      {
         file = chooser.getSelectedFile();
         FileReader fr = new FileReader (file);
         BufferedReader inFile = new BufferedReader (fr);

         String info = "";
         String line = inFile.readLine();
         while (line != null)
         {
            info += line + "\n";
            line = inFile.readLine();
         }

         ta.setText (info);
      }

      JButton saveButton = new JButton("Save File");
      saveButton.addActionListener(new SaveListener());

      setLayout (new BorderLayout());
      add (saveButton, BorderLayout.NORTH);
      add (ta, BorderLayout.CENTER);
   }

   //-----------------------------------------------------------------
   //  Saves the file as changed in the text area.
   //-----------------------------------------------------------------
   private void saveFile()
   {
      if (file == null)
         ta.setText ("Not Saved - Invalid file");
      else
      {
         try
         {
            FileWriter fw = new FileWriter (file);
            BufferedWriter outFile = new BufferedWriter (fw);

            outFile.write(ta.getText());
            outFile.close();
            ta.setText ("File Saved in " + file);
         }
         catch (IOException e)
         {
            ta.setText ("Not Saved - Invalid File");
         }

      }
    }

   //*****************************************************************
   //  Represents the listener for the save button.
   //*****************************************************************
   class SaveListener implements ActionListener
   {
      //-----------------------------------------------------------------
      //  Saves the file in the text area.
      //-----------------------------------------------------------------
      public void actionPerformed(ActionEvent e)
      {
         saveFile();
      }
   }
}
