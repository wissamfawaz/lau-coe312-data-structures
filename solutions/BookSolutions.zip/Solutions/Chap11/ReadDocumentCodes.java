//********************************************************************
//  ReadDocumentCodes.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 11.3 
//********************************************************************

import java.util.Scanner;

public class ReadDocumentCodes
{
   //-----------------------------------------------------------------
   //  Creates an exception object and throws it as appropriate.
   //-----------------------------------------------------------------
   public static void main (String[] args) throws InvalidDocumentCodeException
   {
      String input = "";

      Scanner scan = new Scanner (System.in);

      InvalidDocumentCodeException docException =
         new InvalidDocumentCodeException ("Not a recognized document code.");

      System.out.println("Enter document codes, enter XX when finished:");

	  do
      {
         input = scan.nextLine();
         if (!input.equals("XX"))
            if (input.charAt(0) != 'U' && input.charAt(0) != 'C' && input.charAt(0) != 'P')
               throw docException;
            else
               System.out.println ("Current document code: " + input);
      }
      while (!input.equals("XX"));

      System.out.println("Program successfully completed");
   }
}
