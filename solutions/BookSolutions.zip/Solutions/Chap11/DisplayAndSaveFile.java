//********************************************************************
//  DisplayAndSaveFile.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 11.5 
//********************************************************************

import javax.swing.JFrame;
import java.io.IOException;

public class DisplayAndSaveFile
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args) throws IOException
   {
      JFrame frame = new JFrame ("Display and Save File");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add (new DisplayAndSaveFilePanel());
      frame.pack();
      frame.setVisible (true);
   }
}
