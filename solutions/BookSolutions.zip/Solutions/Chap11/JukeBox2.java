//********************************************************************
//  JukeBox2.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 11.6
//********************************************************************

import javax.swing.*;

public class JukeBox2
{
   //-----------------------------------------------------------------
   //  Creates and displays the JukeBoxControls frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Java Juke Box 2");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      JukeBoxControls2 controlPanel = new JukeBoxControls2();
      frame.getContentPane().add(controlPanel);
      frame.pack();
      frame.setVisible(true);
   }
}
