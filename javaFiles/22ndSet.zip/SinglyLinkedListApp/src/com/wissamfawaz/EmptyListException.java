package com.wissamfawaz;

public class EmptyListException extends Exception {
	public EmptyListException(String msg) {
		super(msg);
	}
}
