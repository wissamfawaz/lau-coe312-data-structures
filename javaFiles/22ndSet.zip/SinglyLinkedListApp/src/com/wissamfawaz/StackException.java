package com.wissamfawaz;

public class StackException extends Exception {
	public StackException(String msg) {
		super(msg);
	}
}
