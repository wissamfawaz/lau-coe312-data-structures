package com.wissamfawaz;

public interface Stack<T> {
	public int size();
	public boolean isEmpty();
	
	public T top() throws StackException;
	public T pop() throws StackException;
	public void push(T e);

}
