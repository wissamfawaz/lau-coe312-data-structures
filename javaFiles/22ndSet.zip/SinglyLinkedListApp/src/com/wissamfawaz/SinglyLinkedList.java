package com.wissamfawaz;

public class SinglyLinkedList<T> implements SList<T> {
	private SNode<T> head, tail;
	public int size;
	
	public SinglyLinkedList() {
		head = tail = null;
		size = 0;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	@Override
	public void insertAtHead(T e) {
		SNode<T> newHead = new SNode<>(e, head);
		
		if(isEmpty()) {
			tail = newHead;
		}
		
		head = newHead;
		
		size++;
	}

	@Override
	public void insertAtTail(T e) {
		SNode<T> newTail = new SNode<>(e, null);
		
		if(isEmpty()) {
			head = newTail;
		} else {
			tail.setNext(newTail);
		}
		
		tail = newTail;
		size++;

	}

	@Override
	public T removeFromHead() throws EmptyListException {
		if(isEmpty()) {
			throw new EmptyListException("List is empty!");
		}
		T toReturn = head.getElement();

		if(head == tail) {
			head = tail = null;
		} else {
			SNode<T> temp = head;
			head = head.getNext();
			temp.setNext(null);
			temp = null;
		}
		
		size--;
		return toReturn;
	}

	@Override
	public T removeFromTail() throws EmptyListException {
		if(isEmpty()) {
			throw new EmptyListException("List is empty!");
		}
		
		T toReturn = tail.getElement();
		if(head == tail) {
			head = tail = null;
		} else {
			SNode<T> temp = head;
			while(temp.getNext() != tail) {
				temp = temp.getNext();
			}
			temp.setNext(null);
			tail = temp;
		}

		size--;
		return toReturn;
	}

	@Override
	public T getHead() throws EmptyListException {
		if(isEmpty()) {
			throw new EmptyListException("List is empty!");
		}
		return head.getElement();
	}

	@Override
	public T getTail() throws EmptyListException {
		if(isEmpty()) {
			throw new EmptyListException("List is empty!");
		}
		return tail.getElement();
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		SNode<T> temp = head;
		while(temp != null) {
			sb.append(temp.getElement() + " ");
			temp = temp.getNext();
		}
		
		return sb.toString();
	}
	
}
