package com.wissamfawaz;

public class SinglyLinkedListDemo {

	public static void main(String[] args) throws EmptyListException {
		SList<Integer> sll = new SinglyLinkedList<>();
		sll.insertAtHead(1);
		sll.insertAtTail(5);
		sll.insertAtHead(2);
		
		System.out.println(sll);

	}

}
