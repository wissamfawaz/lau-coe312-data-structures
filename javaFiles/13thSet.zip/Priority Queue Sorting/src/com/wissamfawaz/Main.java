package com.wissamfawaz;

import java.util.Arrays;
import java.util.PriorityQueue;

public class Main {

	public static void main(String[] args) {
		Point[] points = {
			new Point(0, 0),
			new Point(-1, 0),
			new Point(1, 0),
			new Point(1, 1)
		};
		
		System.out.println("Original list: " + Arrays.toString(points));
		Point[] sortedPoints = pqSort(points);
		System.out.println("Sorted list of points: " + Arrays.toString(sortedPoints));
	}

	private static Point[] pqSort(Point[] points) {
		PriorityQueue<Point> pq = new PriorityQueue<>(new PointsComparator());
		Point[] sortedPoints = new Point[points.length];
		
		// Insertion step
		for(Point p : points) {
			pq.add(p); // pq.offer
		}
		
		
		// Selection step
		int runningIdx = 0;
		
		while(!pq.isEmpty()) {
			sortedPoints[runningIdx++] = pq.remove(); // pq.poll
			// runningIdx++;
		}
		
		
		return sortedPoints;
		
	}
	
	
	
	
	
	
	
	
}
