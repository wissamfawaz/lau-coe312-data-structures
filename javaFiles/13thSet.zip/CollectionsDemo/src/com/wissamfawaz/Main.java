package com.wissamfawaz;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		String[] suits = {"Hearts", "Clubs", "Spades", "Diamonds"};
		System.out.println("Original list: " + Arrays.toString(suits));
		
		LinkedList<String> suitsAsLL = new LinkedList<>(Arrays.asList(suits));
		Collections.sort(suitsAsLL);
		System.out.println("Suits sorted in ascending order: " + suitsAsLL);
		Collections.sort(suitsAsLL, Collections.reverseOrder());
		System.out.println("Suits sorted in a descending order: " + suitsAsLL);
		
		System.out.println("Min: " + Collections.min(suitsAsLL));
		System.out.println("Max: " + Collections.max(suitsAsLL));
		
		Collections.shuffle(suitsAsLL);
		System.out.println("Shuffled list of suits: " + suitsAsLL);
		
		String[] copyArray = new String[suitsAsLL.size()];
		LinkedList<String> copyList = new LinkedList<>(Arrays.asList(copyArray));
		Collections.copy(copyList, suitsAsLL);
		System.out.println("Copy: " + copyList);
		System.out.println("Disjoint? " + Collections.disjoint(suitsAsLL, copyList));
		
		suitsAsLL.addAll(copyList);
		System.out.println("Nb of diamonds in original list: " + 
				Collections.frequency(suitsAsLL, "Diamonds"));
		
		
		
	}

}
