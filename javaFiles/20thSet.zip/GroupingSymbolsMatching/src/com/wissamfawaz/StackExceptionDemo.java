package com.wissamfawaz;

public class StackExceptionDemo {

	public static void main(String[] args) throws Exception {
		ArrayBasedStack stack = new ArrayBasedStack(3);
		
		stack.push(3);
		stack.push(2);
		stack.push(1);
		
		System.out.println("Size: " + stack.size());
		System.out.println("Top element: " + stack.top());
		while(!stack.isEmpty()) {
			System.out.print(stack.pop() + " ");
		}

	}

}
