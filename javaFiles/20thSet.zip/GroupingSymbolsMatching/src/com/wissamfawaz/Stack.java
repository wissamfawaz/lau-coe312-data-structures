package com.wissamfawaz;

public interface Stack {

	public int size();
	public boolean isEmpty();
	
	public Object top() throws StackException;
	public Object pop() throws StackException;
	public void push(Object obj) throws StackException;
	
}
