package com.wissamfawaz;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
	private static String openingSymbols = "([{";
	private static String closingSymbols = ")]}";
	private static Map<Character, Character> symbolMatchingMap = new HashMap<>();
	public static void main(String[] args) throws Exception {
		String expression;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter an expression to validate: ");
		expression = scan.nextLine();
		
		for(int idx = 0; idx < closingSymbols.length(); idx++) {
			symbolMatchingMap.put(closingSymbols.charAt(idx), 
					openingSymbols.charAt(idx));
		}
		
		if(validate(expression)) {
			System.out.println("Input expression is valid.");
		} else {
			System.out.println("Input expression is not valid.");
		}
		
		scan.close();
	}

	private static boolean validate(String expression) throws Exception {
		ArrayBasedStack stack = new ArrayBasedStack(expression.length());
		char current;
		
		for(int idx = 0; idx < expression.length(); idx++) {
			current = expression.charAt(idx);
			
			if(openingSymbols.indexOf(current) != -1) {
				stack.push(current);
			} else if(closingSymbols.indexOf(current) != -1) {
				if(stack.size() == 0) {
					return false;
				}
				
				if(stack.top() != symbolMatchingMap.get(current)) {
					return false;
				}
				
				stack.pop();
			}
		}
		
		return stack.size() == 0;
		
	}
	
	
	
	
	
	
	
	
}
