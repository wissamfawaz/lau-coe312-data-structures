package com.wissamfawaz;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class Main {

	public static void main(String[] args) {
		String secret, decodedMessage;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter a secret message: ");
		secret = scan.nextLine();
		
		decodedMessage = decode(secret);
		
		System.out.println("That message decoded: " + decodedMessage);
		
		scan.close();
	}
	
	private static String decode(String secret) {
		List<String> words = Arrays.asList(secret.split("\\s+"));
		StringBuilder sb = new StringBuilder();
		for(String word : words) {
			sb.append(reverse(word) + " ");
		}
		return sb.toString();
	}
	
	private static String reverse(String word) {
		StringBuilder sb = new StringBuilder();
		Stack<Character> stack = new Stack<>();
		
		for(char letter : word.toCharArray()) {
			stack.push(letter);
		}
		
		while(!stack.isEmpty()) {
			sb.append(stack.pop());
		}
		
		return sb.toString();
	}
	
	
	
	

}
