package com.wissamfawaz;

import java.util.Arrays;
import java.util.HashSet;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		String[] colors = {
				"Red", "Red", "Green", "Green",
				"Yellow", "Yellow"
		};

		HashSet<String> colorsAsHS = new HashSet<>(Arrays.asList(colors));
		System.out.println("Colors without duplicates: " + colorsAsHS);
		
		TreeSet<String> colorsAsTS = new TreeSet<>(colorsAsHS);
		System.out.println("Colors without duplicates and orderd: " + 
				colorsAsTS);
		
		System.out.println("Smallest color: " + colorsAsTS.first());
		System.out.println("Largest color: " + colorsAsTS.last());
		
		System.out.println("Colors that are less than Red: " + 
				colorsAsTS.headSet("Red"));
		System.out.println("Colors that are greater than or equal to Red: " + 
				colorsAsTS.tailSet("Red"));
		
		
		System.out.println("Largest value smaller than Red: " + 
				colorsAsTS.lower("Red"));
		System.out.println("Smallest value larger than Red: " + 
				colorsAsTS.higher("Red"));
		
		
		
		
		
		
		
		
		
	}
}
