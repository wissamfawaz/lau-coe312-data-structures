package com.wissamfawaz;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class Main {

	public static void main(String[] args) {
		String[] colors1 = { "White", "Black" };
		// System.out.println(Arrays.toString(colors1));
		List<String> colors1AsLL = new LinkedList<>(Arrays.asList(colors1));
		System.out.println("List#1: " + colors1AsLL);

		String[] colors2 = { "Red", "Green", "Blue" };
		List<String> colors2AsLL = new LinkedList<>();

		for (String color : colors2) {
			colors2AsLL.add(color);
		}
		System.out.println("List#2: " + colors2AsLL);
		
		colors1AsLL.addAll(colors2AsLL);
		System.out.println("Modified list#1: " + colors1AsLL);
		
		// Print the elements of the colors1AsLL (first list) in reverse order
		printReversedList(colors1AsLL);
		
		// Convert the elements of first list into uppercase
		convertToUpperCase(colors1AsLL);
		System.out.println("Colors in uppercase: " + colors1AsLL);
		
		// Remove a subset of items from first list
		removeItems(colors1AsLL, 1, 3);
		System.out.println("After removing the items: " + colors1AsLL);	
	}
	
	private static void printReversedList(List<String> list) {
		// Iterator is created: Space complexity O(1) Time complexity: O(1)
		ListIterator<String> listIterator = list.listIterator(list.size());
		while(listIterator.hasPrevious()) {
			System.out.print(listIterator.previous() + " ");
		}
		System.out.println();
	}
	
	private static void convertToUpperCase(List<String> list) {
		ListIterator<String> listIterator = list.listIterator();
		while(listIterator.hasNext()) {
			listIterator.set(listIterator.next().toUpperCase());
		}	
	}
	
	private static void removeItems(List<String> list, int start, int end) {
		list.subList(start, end).clear();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
