package com.wissamfawaz;

public class ExceptionScope {
	public void method1() {
		System.out.println("Method1 beginning");
		try {
			method2();
		} catch (ArithmeticException e) {
			e.printStackTrace();
			System.out.println("Message: " + e.getMessage());
		}
		
		System.out.println("Method1 end");
	}
	
	private void method2() {
		System.out.println("Method2 beginning");
		method3();
		System.out.println("Method2 end");
	}
	
	private void method3() {
		System.out.println("Method3 beginning");
		System.out.println(10 / 0);
		System.out.println("Method3 end");
	}

}
