package com.wissamfawaz;

public class Main {

	public static void main(String[] args) {
		System.out.println("Main beginning");

		ExceptionScope scope = new ExceptionScope();

		scope.method1();
		

		System.out.println("Main end");

	}

}
