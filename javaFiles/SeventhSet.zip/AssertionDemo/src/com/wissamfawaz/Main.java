package com.wissamfawaz;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		int value;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a value between 1 and 10: ");
		value = scan.nextInt();
		scan.close();
		
		//assert (value>=1 && value <= 10);
		assert (value>=1 && value <= 10) : "Bad number: " + value;

		System.out.println("Value: " + value);
	}

}
