package com.wissamfawaz;

public class OutOfRangeException extends Exception {
	public OutOfRangeException(String msg) {
		super(msg);
	}

}
