package com.wissamfawaz;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws OutOfRangeException{
		int value;
		final int LOWER = 0, UPPER = 10;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a value between " + LOWER + 
				" and " + UPPER);
		value = scan.nextInt();
		scan.close();
		
		if(value < 0 || value > 10) {
			throw new OutOfRangeException("Invalid value");
		}

		System.out.println("Value: " + value);
	}

}
