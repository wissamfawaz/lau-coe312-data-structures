package com.wissamfawaz;

import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		int[] array = {1, 5, 3, 2, 4};
		System.out.println("Original array: " + 
				Arrays.toString(array));
		
		// Time complexity: O(n log2(n)) 
		// Space complexity: O(n)
		int[] sortedArray = mergeSort(array);
		
		System.out.println("That array sorted: " + 
				Arrays.toString(sortedArray));

	}
	
	private static int[] mergeSort(int[] array) {
		if(array == null || array.length == 0) {
			return array;
		}
		
		mergeSortRec(array, 0, array.length - 1);
		
		return array;
	}
	
	private static void mergeSortRec(int[] array, int left, int right) {
		if(left >= right) {
			return;
		}
		
		int middle = left + (right - left)/2;
		// T(n/2)
		mergeSortRec(array, left, middle);
		// T(n/2) 
		mergeSortRec(array, middle + 1, right);
		
		// n
		merge(array, left, middle, middle + 1, right);
	}
	
	private static void merge(int[] array, int left, int leftEnd, 
			int right, int rightEnd) {
		int sortedArraySize = rightEnd - left + 1;
		int[] sortedArray = new int[sortedArraySize];
		
		int leftPtr = left, rightPtr = right;
		int sortedArrayPtr = 0;
		
		while(leftPtr <= leftEnd && rightPtr <= rightEnd) {
			if(array[leftPtr] < array[rightPtr]) {
				sortedArray[sortedArrayPtr++] = array[leftPtr++];
			} else {
				sortedArray[sortedArrayPtr++] = array[rightPtr++];
			}
		}
		
		while(leftPtr <= leftEnd) {
			sortedArray[sortedArrayPtr++] = array[leftPtr++];
		}
		
		while(rightPtr <= rightEnd) {
			sortedArray[sortedArrayPtr++] = array[rightPtr++];
		}
		
		System.arraycopy(sortedArray, 0, array, left, sortedArraySize);
		
		
		
	}
	
	
	
	

}
