package com.wissamfawaz;

public class QueueException extends Exception {
	public QueueException(String msg) {
		super(msg);
	}
}
