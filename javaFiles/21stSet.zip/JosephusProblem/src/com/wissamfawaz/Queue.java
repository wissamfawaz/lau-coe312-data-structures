package com.wissamfawaz;

public interface Queue {

	public int size();
	public boolean isEmpty();
	
	public Object front() throws QueueException;
	public Object dequeue() throws QueueException;
	public void enqueue(Object obj) throws QueueException;
	
}
