package com.wissamfawaz;

public class CheckingAccount extends BankAccount {
	private int transactionsCount;
	private final int THRESHOLD = 3;
	private final double FEE = 0.5;
	
	public CheckingAccount(double balance) {
		super(balance);
		transactionsCount = 0;
	}

	@Override
	public void withdraw(double amount) {
		super.withdraw(amount);
		transactionsCount++;
	}
	
	@Override
	public void deposit(double amount) {
		super.deposit(amount);
		transactionsCount++;
	}
	
	public void applyFees() {
		if(transactionsCount > THRESHOLD) {
			double fees = (transactionsCount - THRESHOLD) * FEE;
			super.withdraw(fees);
		}
		transactionsCount = 0;
	}
	
}
