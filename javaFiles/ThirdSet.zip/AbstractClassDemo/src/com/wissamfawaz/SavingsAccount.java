package com.wissamfawaz;

public class SavingsAccount extends BankAccount {
	private final double RATE;
	public SavingsAccount() {
		RATE = 0.25;
	}

	public void addInterest() {
		deposit(RATE*balance);
	}
}
