package com.wissamfawaz;

public abstract class BankAccount {
	protected double balance;
	
	public BankAccount() {
		balance = 0;
	}
	
	public BankAccount(double balance) {
		this.balance = balance;
	}
	
	
	public double getBalance() {
		return balance;
	}
	
	public void withdraw(double amount) {
		if(amount > 0) {
			balance -= amount;
		}
	}
	
	public void deposit(double amount) {
		if(amount > 0) {
			balance += amount;
		}
		
	}
	

}
