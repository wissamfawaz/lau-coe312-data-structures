package com.wissamfawaz;

public class Main {

	public static void main(String[] args) {
		Die die1 = new Die(5);
		Die die2 = new Die(5);
		
		
		
		if(die1.equals(die2)) {
			System.out.println("They are identical");
		} else {
			System.out.println("They are not identical");
		}

	}

}
