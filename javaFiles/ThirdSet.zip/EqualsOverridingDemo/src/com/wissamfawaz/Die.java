package com.wissamfawaz;

public class Die {
	private int faceValue;

	public Die(int faceValue) {
		this.faceValue = faceValue;
	}

	public int getFaceValue() {
		return faceValue;
	}

	public void setFaceValue(int faceValue) {
		this.faceValue = faceValue;
	}
	
	@Override
	public String toString() {
		return Integer.toString(faceValue);
	}
	
	@Override
	public boolean equals(Object other) {
		if(other == null || getClass() != other.getClass()) {
			return false;
		}
		Die otherAsDie = (Die) other;
		return faceValue == otherAsDie.getFaceValue();
	}
	

}
