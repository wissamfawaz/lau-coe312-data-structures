package com.wissamfawaz;

public class Violin extends Instrument {

	@Override
	public void play() {
		System.out.println("Violin play.");

	}

}
