package com.wissamfawaz;

public class Main {

//	private static void tune(Piano p) {
//		p.play();
//	}
//	
//	private static void tune(Violin v) {
//		v.play();
//	}
//	
//	private static void tune(Guitar g) {
//		g.play();
//	}
	
	private static void tune(Instrument i) {
		i.play();
	}
	
	public static void main(String[] args) {
		Instrument i = new Guitar();
		tune(i);
		i = new Violin();
		tune(i);
		i = new Piano();
		tune(i);

	}

}
