package com.wissamfawaz;

public class Piano extends Instrument {

	@Override
	public void play() {
		System.out.println("Piano play.");

	}

}
