package com.wissamfawaz;

import java.math.BigInteger;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		int n;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter n (-1 to quit): ");
		n = scan.nextInt();
		
		while(n != -1 ) {
			System.out.println("Iterative solution: " + fact_iter(n));
			System.out.println("Recursive solution: " + fact_rec(n));
			System.out.println("Accurate solution: " + fact_acc(n));
			System.out.println("Enter n (-1 to quit): ");
			n = scan.nextInt();
		}
		
		
		scan.close();
	}

	private static long fact_iter(int n) {
		long product = 1L;
		
		for(int i=1; i<=n; i++) {
			product *= i;
		}
		
		return product;
		
	}

	private static long fact_rec(int n) {
		if(n == 0) {
			return 1L;
		}
		
		return n * fact_rec(n-1);
	}

	private static BigInteger fact_acc(int n) {
		BigInteger product = BigInteger.ONE;
		
		for(int i=1; i<=n; i++) {
			product = product.multiply(BigInteger.valueOf(i));
		}
	
		return product;
	}
	
	
}
 