package com.wissamfawaz;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		int n;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter n: ");
		n = scan.nextInt();
		
		System.out.println("Iterative solution: " + sum_iter(n));
		System.out.println("Recursive solution: " + sum_rec(n));
		
		scan.close();
	}

	private static long sum_iter(int n) {
		long sum = 0L;
		
		for(int i=1; i<=n; i++) {
			sum+=i;
		}
		
		return sum;
	}
	
	private static long sum_rec(int n) {
		// Base case
		if(n == 0) {
			return 0;
		}
		
		// Recursive part
		return n + sum_rec(n-1);
		
		
	}
	
}
