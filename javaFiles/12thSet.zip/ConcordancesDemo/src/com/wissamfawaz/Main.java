package com.wissamfawaz;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Main {
	private static HashMap<String, Integer> map = new HashMap<>();
	public static void main(String[] args) {
		String line;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter a line of text: ");
		line = scan.nextLine();
		
		populateHashMap(line);
		displaySummary();
		
		scan.close();
	}

	private static void populateHashMap(String line) {
		line = line.replaceAll("\\p{P}", "");
		String[] words = line.split("\\s+");
		
		for(String word : words) {
			if(map.containsKey(word)) {
				int count = map.get(word);
				map.put(word, count + 1);
			} else {
				map.put(word, 1);
			}
		}
	}
	
	private static void displaySummary() {
		Set<String> wordsSet = map.keySet();
		TreeSet<String> wordsSorted = new TreeSet<>(new WordsComparator());
		
		for(String word : wordsSet) {
			wordsSorted.add(word);
		}
		
		for(String word : wordsSorted) {
			System.out.println(word + ": " + map.get(word));
		}
		
	}
	
}
