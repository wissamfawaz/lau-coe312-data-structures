package com.wissamfawaz;

import java.util.ArrayList;
import java.util.List;

public class History {
	private List<EditorState> states = new ArrayList<>();

	public void push(EditorState state) {
		states.add(state);
	}
	
	public EditorState pop() {
		int lastIdx = states.size() - 1;
		EditorState prevState = null;
		
		if(lastIdx >= 0) {
			prevState = states.get(lastIdx);
			states.remove(lastIdx);
		}
		
		return prevState;
	}
}
