package com.wissamfawaz;

import java.util.Scanner;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Timer;

public class Main {
	private int counter;

	public Main(int counter) {
		this.counter = counter;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int count;
		
		System.out.println("Enter an initial value for the counter: ");
		count = scan.nextInt();
		
		Main application = new Main(count);
		application.startCountDown();
		
		scan.close();
	}
	
	public void startCountDown() {
		Timer timer = new Timer(1000, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(counter >= 0) {
					System.out.println(counter);
				}
				if(counter == -1) {
					System.out.println("LiftOff!");
				}
				counter--;
			}
		});
		
//		Timer timer = new Timer(1000, (e) -> {
//			if(counter >= 0) {
//				System.out.println(counter);
//			}
//			if(counter == -1) {
//				System.out.println("LiftOff!");
//			}
//			counter--;
//		});
		
		
		timer.setInitialDelay(0);
		timer.start();
		
		while(timer.isRunning()) {
			if(counter <= -2) {
				timer.stop();
			}
		}
	}
	
//	private class EventHandler implements ActionListener {
//
//		@Override
//		public void actionPerformed(ActionEvent e) {
//			if(counter >= 0) {
//				System.out.println(counter);
//			}
//			if(counter == -1) {
//				System.out.println("LiftOff!");
//			}
//			counter--;
//		}
//		
//	}
	
	
	
	
	
	
	

}
