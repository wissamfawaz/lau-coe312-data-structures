package com.wissamfawaz;

public interface Position<T> {
	public T getElement();
}
