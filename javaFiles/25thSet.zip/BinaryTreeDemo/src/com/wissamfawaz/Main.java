package com.wissamfawaz;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

public class Main {
	private BTNode<Character> root1;
	private BTNode<Integer> root2;
	private List<Character> depthFirstValuesIter, 
	depthFirstValuesRec;
	private List<Character> breadthFirstValues;
	
	public Main() {
		root1 = new BTNode<>('A');
		BTNode<Character> root1Left = new BTNode<>('B');
		BTNode<Character> root1LeftLeft = new BTNode<>('D');
		BTNode<Character> root1LeftRight = new BTNode<>('E');
		BTNode<Character> root1Right = new BTNode<>('C');
		BTNode<Character> root1RightRight = new BTNode<>('F');
		
		root1.setLeft(root1Left); root1Left.setLeft(root1LeftLeft);
		root1Left.setRight(root1LeftRight);
		root1.setRight(root1Right); root1Right.setRight(root1RightRight);
		
		root2 = new BTNode<>(3);
		BTNode<Integer> root2Left = new BTNode<>(11);
		BTNode<Integer> root2LeftLeft = new BTNode<>(4);
		BTNode<Integer> root2LeftRight = new BTNode<>(2);
		BTNode<Integer> root2Right = new BTNode<>(4);
		BTNode<Integer> root2RightRight = new BTNode<>(1);
		
		root2.setLeft(root2Left); root2Left.setLeft(root2LeftLeft);
		root2Left.setRight(root2LeftRight);
		root2.setRight(root2Right); root2Right.setRight(root2RightRight);

		depthFirstValuesIter = new ArrayList<>();
		depthFirstValuesRec = new ArrayList<>();
		breadthFirstValues = new ArrayList<>();
	}
	

	public static void main(String[] args) {
		Main application = new Main();
		
		application.dfsTraversalIter();
		application.printList(application.depthFirstValuesIter);
		
		application.dfsTraversalRec();
		application.printList(application.depthFirstValuesRec);
		
		application.bfsTraversal();
		application.printList(application.breadthFirstValues);
		
		Character target = 'e';
		
		if(application.bTreeIncludes(target)) {
			System.out.println(target + " is part of binary tree");
		} else {
			System.out.println(target + " is not part of binary tree");
		}
		
		System.out.println("Sum of the values of the binary tree: " + 
				application.bTreeSum());
		System.out.println("Min value in the binary tree: " + 
				application.bTreeMin());
		System.out.println("Max path sum: " + application.bTreeMaxPathSum());
	}

	private void dfsTraversalIter() {
		if(root1 == null) {
			return;
		}
		
		Stack<BTNode<Character>> stack = new Stack<>();
		BTNode<Character> current;
		stack.push(root1);
		
		while(!stack.isEmpty()) {
			current = stack.pop();
			depthFirstValuesIter.add(current.getElement());
			
			if(current.hasRight()) {
				stack.push(current.getRight());
			}
			
			if(current.hasLeft()) {
				stack.push(current.getLeft());
			}
		}		
	}

	private void dfsTraversalRec() {
		dfsTraversalRecUtil(root1);
	}
	
	private void dfsTraversalRecUtil(BTNode<Character> node) {
		if(node == null) {
			return;
		}
		
		depthFirstValuesRec.add(node.getElement());
		dfsTraversalRecUtil(node.getLeft());
		dfsTraversalRecUtil(node.getRight());
	}

	private void bfsTraversal() {
		if(root1 == null) {
			return;
		}
		
		Queue<BTNode<Character>> queue = new LinkedList<>();
		BTNode<Character> current;
		queue.add(root1);
		
		while(!queue.isEmpty()) {
			current = queue.remove();
			breadthFirstValues.add(current.getElement());
			
			if(current.hasLeft()) {
				queue.add(current.getLeft());
			}
			
			if(current.hasRight()) {
				queue.add(current.getRight());
			}
		}		
	}
	
	private boolean bTreeIncludes(Character target) {
		return bTreeIncludesRec(target, root1);
	}
	
	private boolean bTreeIncludesRec(Character target, BTNode<Character> node) {
		if(node == null) {
			return false;
		}
		
		if(node.getElement() == target) {
			return true;
		}
		
		return 
				bTreeIncludesRec(target, node.getLeft()) ||
				bTreeIncludesRec(target, node.getRight());		
	}
	
	private int bTreeSum() {
		return bTreeSumRec(root2);
	}
	
	private int bTreeSumRec(BTNode<Integer> node) {
		if(node == null) {
			return 0;
		}
		
		int leftSum = bTreeSumRec(node.getLeft());
		int rightSum = bTreeSumRec(node.getRight());
		
		return node.getElement() + leftSum + rightSum;
	}
	
	
	private int bTreeMin() {
		return bTreeMinRec(root2);
	}
	
	private int bTreeMinRec(BTNode<Integer> node) {
		if(node == null) {
			return Integer.MAX_VALUE;
		}
		
		int leftMin = bTreeMinRec(node.getLeft());
		int rightMin = bTreeMinRec(node.getRight());
		
		return Math.min(node.getElement(), Math.min(leftMin, rightMin));
	}
	
	
	private int bTreeMaxPathSum() {
		return bTreeMaxPathSumRec(root2);
	}
	
	private int bTreeMaxPathSumRec(BTNode<Integer> node) {
		if(node == null) {
			return Integer.MIN_VALUE;
		}
		
		if(node.getLeft() == null && node.getRight() == null) {
			return node.getElement();
		}
		
		int leftPathSum = bTreeMaxPathSumRec(node.getLeft());
		int rightPathSum = bTreeMaxPathSumRec(node.getRight());
		
		return node.getElement() + Math.max(leftPathSum, rightPathSum);
	}
	
	
	private void printList(List<Character> list) {
		System.out.println(list);
	}
	
}
