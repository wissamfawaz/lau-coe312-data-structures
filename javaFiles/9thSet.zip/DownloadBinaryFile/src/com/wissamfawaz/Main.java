package com.wissamfawaz;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public class Main {

	public static void main(String[] args) throws Exception {
		URL url = new URL("https://wissamfawaz.com/MyPhoto.jpg");
		URLConnection urlConnection = url.openConnection();
		InputStream is = urlConnection.getInputStream();
		
		BufferedInputStream inFromURL = new BufferedInputStream(is);
		FileOutputStream fos = new FileOutputStream(new File("profile.jpg"));

		byte[] buffer = new byte[1024];
		int len;
		
		while((len = inFromURL.read(buffer)) > 0) {
			fos.write(buffer, 0, len);
		}
		
		inFromURL.close();
		fos.close();
	}

}
