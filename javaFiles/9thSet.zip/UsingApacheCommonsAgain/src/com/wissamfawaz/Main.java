package com.wissamfawaz;

import java.io.File;
import java.net.URL;

import org.apache.commons.io.FileUtils;

public class Main {

	public static void main(String[] args) throws Exception {
		URL url = new URL("https://soe.lau.edu.lb/images/faculty-wissam-fawwaz.jpg");
		File trgtFile = new File("profile.jpg");
		FileUtils.copyURLToFile(url, trgtFile);

	}

}
