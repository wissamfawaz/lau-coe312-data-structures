package com.wissamfawaz;

public class Main {

	public static void main(String[] args) throws Exception {
		DoublyLinkedList<Integer> dll = new DoublyLinkedList<>();
	
		dll.insertFirst(1);
		dll.insertLast(4);
		dll.insertAfter(dll.first(), 2);
		dll.insertBefore(dll.last(), 3);
		
		for(DNode<Integer> d : dll) {
			System.out.print(d.getElement() + " ");
		}
		System.out.println();
		//System.out.println(dll);
		
		System.out.println("After removing " + dll.remove(dll.first()) + 
				", dll: " + dll);

	}

}
