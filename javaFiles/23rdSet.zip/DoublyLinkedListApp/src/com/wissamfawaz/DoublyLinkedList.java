package com.wissamfawaz;

import java.util.Iterator;
import java.util.Stack;

public class DoublyLinkedList<T> implements DList<T>, Iterable<DNode<T>> {
	private DNode<T> header, trailer;
	private int size;

	public DoublyLinkedList() {
		header = new DNode<>(null, null, null);
		trailer = new DNode<>(header, null, null);
		header.setNext(trailer);
		size = 0;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return (size == 0);
	}

	@Override
	public DNode<T> first() throws EmptyListException {
		if (isEmpty())
			throw new EmptyListException("List is empty!");
		return header.getNext();
	}

	@Override
	public DNode<T> last() throws EmptyListException {
		if (isEmpty()) {
			throw new EmptyListException("List is empty!");
		}
		return trailer.getPrevious();
	}

	private void checkPosition(DNode<T> d) throws InvalidPositionException {
		if (d == null) {
			throw new InvalidPositionException("Null is not a valid position!");
		}

		if (d == header) {
			throw new InvalidPositionException("Header is not a valid position!");
		}

		if (d == trailer) {
			throw new InvalidPositionException("Trailer is not a valid position!");
		}

		if (d.getPrevious() == null || d.getNext() == null) {
			throw new InvalidPositionException("DNode is not part of a DList!");
		}
	}

	@Override
	public DNode<T> prev(DNode<T> d) throws InvalidPositionException, BoundaryViolationException {
		checkPosition(d);
		if (d.getPrevious() == header) {
			throw new BoundaryViolationException("Cannot move past first node!");
		}
		return d.getPrevious();
	}

	@Override
	public DNode<T> next(DNode<T> d) throws InvalidPositionException, BoundaryViolationException {
		checkPosition(d);
		if (d.getNext() == trailer) {
			throw new BoundaryViolationException("Cannot move past last node!");
		}
		return d.getNext();
	}

	@Override
	public T remove(DNode<T> d) throws InvalidPositionException {
		checkPosition(d);
		T toReturn = d.getElement();
		d.removeBindings();
		size--;
		return toReturn;
	}

	@Override
	public T replace(DNode<T> d, T e) throws InvalidPositionException {
		checkPosition(d);
		T toReturn = d.getElement();
		d.setElement(e);
		return toReturn;
	}

	@Override
	public DNode<T> insertFirst(T e) {
		DNode<T> newDNode = new DNode<>(header, e, header.getNext());
		header.getNext().setPrevious(newDNode);
		header.setNext(newDNode);
		size++;
		return newDNode;
	}

	@Override
	public DNode<T> insertLast(T e) {
		DNode<T> newDNode = new DNode<>(trailer.getPrevious(), e, trailer);
		trailer.getPrevious().setNext(newDNode);
		trailer.setPrevious(newDNode);
		size++;

		return newDNode;
	}

	@Override
	public DNode<T> insertBefore(DNode<T> d, T e) throws InvalidPositionException {
		checkPosition(d);
		DNode<T> newDNode = new DNode<>(d.getPrevious(), e, d);
		d.getPrevious().setNext(newDNode);
		d.setPrevious(newDNode);
		size++;
		return newDNode;
	}

	@Override
	public DNode<T> insertAfter(DNode<T> d, T e) throws InvalidPositionException {
		checkPosition(d);
		DNode<T> newDNode = new DNode<>(d, e, d.getNext());
		d.getNext().setPrevious(newDNode);
		d.setNext(newDNode);
		size++;
		return newDNode;
	}

//	private class PositionsIterator implements Iterator<DNode<T>> {
//		private Stack<DNode<T>> stack;
//		
//		public PositionsIterator() {
//			stack = new Stack<>();
//			
//			try {
//				DNode<T> temp = last();
//				while(temp != header) {
//					stack.push(temp);
//					temp = temp.getPrevious();
//				}
//			} catch(EmptyListException e) {
//				
//			}
//		}
//
//		@Override
//		public boolean hasNext() {
//			return !stack.isEmpty();
//		}
//
//		@Override
//		public DNode<T> next() {
//			if(!hasNext()) {
//				return null;
//			}
//			return stack.pop();
//		}
//		
//	}

	private class PositionsIterator implements Iterator<DNode<T>> {
		private DNode<T> current;
		
		public PositionsIterator() {
			try {
				current = first();
			} catch(EmptyListException e) {
				current = null;
			}
		}
		
		@Override
		public boolean hasNext() {
			return current != null;
		}

		@Override
		public DNode<T> next() {
			if(!hasNext()) {
				return null;
			}
			DNode<T> toReturn = current;
			
			try {
				if(current == last()) {
					current = null;
				} else {
					current = current.getNext();
				}
			} catch(EmptyListException e) {
				current = null;
			}
			
			return toReturn;
		}

	}

	public Iterator<DNode<T>> positions() {
		return new PositionsIterator();
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		DNode<T> temp = header.getNext();
		while (temp != trailer) {
			sb.append(temp.getElement() + " ");
			temp = temp.getNext();
		}

		return sb.toString();
	}

	@Override
	public Iterator<DNode<T>> iterator() {
		return positions();
	}

}
