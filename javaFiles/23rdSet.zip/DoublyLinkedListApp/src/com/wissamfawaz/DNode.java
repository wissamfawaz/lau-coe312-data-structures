package com.wissamfawaz;

public class DNode<T> implements Position<T> {
	private DNode<T> previous, next;
	private T element;

	public DNode(DNode<T> p, T e, DNode<T> n) {
		element = e;
		previous = p;
		next = n;
	}
	
	public DNode<T> getPrevious() {
		return previous;
	}

	public void setPrevious(DNode<T> previous) {
		this.previous = previous;
	}

	public DNode<T> getNext() {
		return next;
	}

	public void setNext(DNode<T> next) {
		this.next = next;
	}

	public void setElement(T element) {
		this.element = element;
	}

	@Override
	public T getElement() {
		return element;
	}

	public String toString() {
		return element.toString();
	}
	
	public void removeBindings() {
		if(previous != null) {
			previous.next = next;
		}
		
		if(next != null) {
			next.previous = previous;
			next = null;
		}
		previous = null;
		
	}
	
	
	
}
