package com.wissamfawaz;

public abstract class Shape {
	public abstract void draw();

}
