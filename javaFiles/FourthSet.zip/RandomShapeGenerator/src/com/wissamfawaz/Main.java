package com.wissamfawaz;

public class Main {

	public static void main(String[] args) {
		Shape[] shapes = new Shape[4];
		
		for(int idx=0; idx < shapes.length; idx++) {
			shapes[idx] = ShapeGenerator.next();
		}
		
		for(Shape s : shapes) {
			System.out.println("Data type: " + s.getClass().getSimpleName());
			s.draw();
		}

	}

}
