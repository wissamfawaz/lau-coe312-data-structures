package com.wissamfawaz;

public class ShapeGenerator {
	
	public static Shape next() {
		int rndValue = (int) (Math.random()*3);
		Shape output;
		switch(rndValue) {
		case 0:
			output = new Triangle();
			break;
		case 1:
			output = new Rectangle();
			break;
		default:
			output = new Circle();
		}
		
		return output;
	}

}
