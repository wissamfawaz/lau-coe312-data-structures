package com.wissamfawaz;

public class Radiobutton implements UIControl {
	@Override
	public void render() {
		System.out.println("Radiobutton rendering");

	}

}
