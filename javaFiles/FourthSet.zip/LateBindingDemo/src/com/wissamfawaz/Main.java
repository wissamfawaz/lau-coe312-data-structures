package com.wissamfawaz;

public class Main {

	public static void main(String[] args) {
		renderUIControl(new Checkbox());
		renderUIControl(new Radiobutton());

	}

	private static void renderUIControl(UIControl control) {
		control.render();
	}
}
