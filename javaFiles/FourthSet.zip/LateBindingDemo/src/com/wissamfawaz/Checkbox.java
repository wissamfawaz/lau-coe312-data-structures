package com.wissamfawaz;

public class Checkbox implements UIControl {

	@Override
	public void render() {
		System.out.println("Checkbox rendering");
	}

}
