package com.wissamfawaz;

public interface UIControl {
	public void render();

}
