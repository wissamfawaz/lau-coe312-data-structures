package com.wissamfawaz;

public class Main {

	public static void main(String[] args) {
		StaffList application  = new StaffList();
		application.payDay();

	}

}
