package com.wissamfawaz;

public class Employee extends StaffMember {
	protected String SSN;
	protected double payRate;

	public Employee(String first, String last, String sSN, double payRate) {
		super(first, last);
		SSN = sSN;
		this.payRate = payRate;
	}



	@Override
	public double pay() {
		return payRate;
	}

	public String toString() {
		return super.toString() + "\n" + 
				"SSN: " + SSN + "\n" + 
				"Rate: " + payRate;
	}
}
