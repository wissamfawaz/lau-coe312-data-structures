package com.wissamfawaz;

public class Hourly extends Employee {
	private int hrsWorked;

	public Hourly(String first, String last, String sSN, double payRate) {
		super(first, last, sSN, payRate);
		hrsWorked = 0;
	}
	
	@Override
	public double pay() {
		double amount = super.pay() * hrsWorked;
		hrsWorked = 0;
		return amount;
	}
	
	public void updateHours(int hrs) {
		hrsWorked += hrs;
	}
	

}
