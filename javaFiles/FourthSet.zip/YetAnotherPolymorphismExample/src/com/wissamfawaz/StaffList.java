package com.wissamfawaz;

public class StaffList {
	private StaffMember[] members;
	
	public StaffList() {
		members = new StaffMember[3];
		
		members[0] = new Volunteer("Wissam", "Fawaz");
		members[1] = new Hourly("Chadi", "Fawaz", "1234", 20);
		members[2] = new Executive("Fawzi", "Fawaz", "2345", 2000);
		
		((Hourly) members[1]).updateHours(80);
		((Executive) members[2]).awardBonus(2000);
	}
	
	public void payDay() {
		for(StaffMember member : members) {
			System.out.println(member);
			double pay = member.pay();
			if(Double.compare(pay, 0) == 0) {
				System.out.println("Thank you!");
			} else {
				System.out.println("Paid amount: " + pay);
			}
			
			System.out.println("---------------------------");
		}
	}

}
