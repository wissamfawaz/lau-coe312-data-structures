package com.wissamfawaz;

public class Volunteer extends StaffMember {
	public Volunteer(String first, String last) {
		super(first, last);
	}

	@Override
	public double pay() {
		return 0;
	}

}
