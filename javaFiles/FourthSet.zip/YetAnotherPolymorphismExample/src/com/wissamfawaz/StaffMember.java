package com.wissamfawaz;

public abstract class StaffMember {
	protected String first;
	protected String last;
	public StaffMember(String first, String last) {
		this.first = first;
		this.last = last;
	}
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getLast() {
		return last;
	}
	public void setLast(String last) {
		this.last = last;
	}
	
	public abstract double pay();
	
	@Override
	public String toString() {
		return "First: " + first + "\n" + 
				"Last: " + last;
	}

}
