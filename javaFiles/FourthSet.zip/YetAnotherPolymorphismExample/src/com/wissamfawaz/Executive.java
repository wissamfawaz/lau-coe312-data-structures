package com.wissamfawaz;

public class Executive extends Employee {
	private double bonus;

	public Executive(String first, String last, String sSN, double payRate) {
		super(first, last, sSN, payRate);
		bonus = 0;
	}
	
	public void awardBonus(double bonus) {
		this.bonus = bonus;
	}
	
	public double pay() {
		double amount = super.pay() + bonus;
		bonus = 0;
		return amount;
	}
	
	@Override
	public String toString() {
		return super.toString() + "\n" + 
				"Bonus: " + bonus;
	}
	

}
