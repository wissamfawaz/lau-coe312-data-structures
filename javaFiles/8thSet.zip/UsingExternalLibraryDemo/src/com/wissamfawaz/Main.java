package com.wissamfawaz;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class Main {

	public static void main(String[] args) {
		File srcFile = new File("profile.jpg");
		File trgtFile = new File("profileCopy.jpg");
		
		try {
			FileUtils.copyFile(srcFile, trgtFile);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
