package com.wissamfawaz;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {
		File srcFile = new File("in.txt");
		File trgtFile = new File("out.txt");
		
		Scanner fileScan = new Scanner(srcFile);
		FileWriter fw = new FileWriter(trgtFile);
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter outToFile = new PrintWriter(bw);
		
		String line;
		
		while(fileScan.hasNextLine()) {
			line = fileScan.nextLine();
			outToFile.println(line);
		}
		
		
		outToFile.close();
		fileScan.close();
		
	}

}
