package com.wissamfawaz;

public class Main {

	public static void main(String[] args) {
		try {
			method1();
		} catch(Exception e) {
			StackTraceElement[] elements = e.getStackTrace();
			
			for(StackTraceElement element : elements) {
				System.out.print(element.getClassName() + "\t");
				System.out.print(element.getMethodName() + "\t");
				System.out.println(element.getLineNumber());
			}
		}

	}

	private static void method1() throws Exception {
		method2();
	}
	
	private static void method2() throws Exception {
		method3();
	}
	private static void method3() throws Exception {
		throw new Exception("Problem inside method3");
	}
}
