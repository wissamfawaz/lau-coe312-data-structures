package com.wissamfawaz;

public class BTNode<T> implements Position<T> {
	private T element;
	private BTNode<T> left, right;
	
	public BTNode(T e) {
		element = e;
		left = right = null;
	}
	
	public BTNode(BTNode<T> left, T e, BTNode<T> right) {
		this.left = left;
		element = e;
		this.right = right;
	}

	public BTNode<T> getLeft() {
		return left;
	}

	public void setLeft(BTNode<T> left) {
		this.left = left;
	}

	public BTNode<T> getRight() {
		return right;
	}

	public void setRight(BTNode<T> right) {
		this.right = right;
	}

	public void setElement(T element) {
		this.element = element;
	}

	@Override
	public T getElement() {
		return element;
	}

	public String toString() {
		return element.toString();
	}
	
	public boolean hasLeft() {
		return left != null;
	}
	
	public boolean hasRight() {
		return right != null;
	}
	
	
	
}
