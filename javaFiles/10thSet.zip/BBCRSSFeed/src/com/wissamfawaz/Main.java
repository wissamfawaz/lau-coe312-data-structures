package com.wissamfawaz;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Main {

	public static void main(String[] args) throws Exception {
		// 1. Create Stream that is attached to URL
		URL url = new URL("http://feeds.bbci.co.uk/news/world/rss.xml");
		InputStream is = url.openStream();

		// 2. Create the DOM
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document document = db.parse(is);

		StringBuilder sb = new StringBuilder("<!DOCTYPE html><html>"
				+ "<head><title>BBC News</title></head><body>");
		File htmlFile = new File("news.html");
		FileWriter fw = new FileWriter(htmlFile);
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter outToFile = new PrintWriter(bw);
		
		NodeList itemsList = document.getElementsByTagName("item");
		Node itemNode;
		Element itemElt;
		
		for(int idx = 0; idx < itemsList.getLength(); idx++) {
			itemNode = itemsList.item(idx);
			itemElt = (Element) itemNode;
			sb.append("<h1>" + 
			itemElt.getElementsByTagName("title").item(0).getTextContent()
			+ "</h1>");
			sb.append("<p>" + 
			itemElt.getElementsByTagName("description").item(0).getTextContent()
			+ "</p>");
			
		}
		
		
		
		
		
		
		
				
		sb.append("</body></html>");
		outToFile.print(sb.toString());
		outToFile.close();
		
		Desktop.getDesktop().browse(htmlFile.toURI());
	}

}
