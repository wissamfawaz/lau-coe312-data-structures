package com.wissamfawaz;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		String[] colors1 = {"White", "Black"};
		//System.out.println(Arrays.toString(colors1));
		List<String> colors1AsLL = new LinkedList<>(Arrays.asList(colors1));
		System.out.println("List#1: " + colors1AsLL);
	
		String[] colors2 = {"Red", "Green", "Blue"};
		List<String> colors2AsLL = new LinkedList<>();
		
		for(String color : colors2) {
			colors2AsLL.add(color);
		}
		System.out.println(colors2AsLL);

	}

}
