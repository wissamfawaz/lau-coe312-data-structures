package com.wissamfawaz;

import java.io.InputStream;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Main {
	public static void main(String[] args) throws Exception {
		URL url = new URL("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_month.geojson");
		InputStream is = url.openStream();
		
		// 1. Create the tokener
		JSONTokener tokener = new JSONTokener(is);
		// 2. Create the main object
		JSONObject mainObj = new JSONObject(tokener);
		JSONArray featuresArray = mainObj.getJSONArray("features");
		JSONObject featureObj, propertiesObj;
		String location;
		double magnitude;
		StringBuilder sb = new StringBuilder();
		for(int idx = 0; idx < featuresArray.length(); idx++) {
			featureObj = featuresArray.getJSONObject(idx);
			propertiesObj = featureObj.getJSONObject("properties");
			location = propertiesObj.getString("place");
			magnitude = propertiesObj.getDouble("mag");
			
			sb.append("Earthquake#" + (idx + 1) + ":\n");
			sb.append("Location: " + location + "\n");
			sb.append("Magnitude: " + magnitude + "\n");
		}
		
		System.out.println(sb);
		
		
	}

}
