package com.wissamfawaz;

public class Shape {
	public void draw() {
		System.out.println("Sahpe draw.");
	}

}
