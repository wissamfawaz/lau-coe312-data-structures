package com.wissamfawaz;

public class Main {

	public static void main(String[] args) {
		Shape s = new Shape();
		s.draw();

		Circle c = new Circle();
		c.draw();
		
		Rectangle r = new Rectangle();
		r.draw();
	}

}
