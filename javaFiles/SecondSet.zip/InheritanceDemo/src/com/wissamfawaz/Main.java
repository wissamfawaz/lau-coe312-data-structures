package com.wissamfawaz;

public class Main {

	public static void main(String[] args) {
		Dictionary dictionary = new Dictionary(1500, 52500);
		System.out.println("Pages: " + dictionary.getPages());
		System.out.println("Definitions: " + dictionary.getDefinitions());
		System.out.println("Avg nb. of defs per page: " + dictionary.defsPerPage());

	}

}
