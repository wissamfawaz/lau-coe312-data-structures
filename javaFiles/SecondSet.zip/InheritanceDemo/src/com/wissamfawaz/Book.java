package com.wissamfawaz;

public class Book {
	protected int pages; // instance variable
	
	public Book(int pages) {
		this.pages = pages;
	}
	
	public int getPages() {
		return pages;
	}
	
	
	
	public void setPages(int pages) {
		this.pages = pages;
	}

}
