package com.wissamfawaz;

public class ToHSolver {
	private int nbDisks;
	
	public ToHSolver(int n) {
		nbDisks = n;
	}
	
	public void solve() {
		moveTower(nbDisks, 1, 3, 2);
	}
	
	private void moveTower(int n, int start, int end, int extra) {
		if(n == 0) {
			return;
		}
		
		moveTower(n-1, start, extra, end);
		moveOneDisk(start, end);
		moveTower(n-1, extra, end, start);
	}
	
	private void moveOneDisk(int start, int end) {
		System.out.println(start + "->" + end);
	}
	
	
	
	

}
