package com.wissamfawaz;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		int n;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter nb of rings: ");
		n = scan.nextInt();
		
		ToHSolver solver = new ToHSolver(n);
		solver.solve();
		
		scan.close();
	}

}
