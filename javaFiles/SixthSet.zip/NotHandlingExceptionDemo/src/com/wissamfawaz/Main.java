package com.wissamfawaz;

public class Main {

	public static void main(String[] args) {
		System.out.println("Main beginning");
		//System.out.println(Double.isNaN(0 / 0.0));
		
		System.out.println(10 / 0);
		
		System.out.println("Main end");

	}

}
