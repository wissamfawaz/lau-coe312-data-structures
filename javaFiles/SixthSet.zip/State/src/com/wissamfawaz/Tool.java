package com.wissamfawaz;

public interface Tool {
	public void mouseDown();
	public void mouseUp();
}
