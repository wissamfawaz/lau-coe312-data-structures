package com.wissamfawaz;

public enum ToolType {
	SELECTION, 
	BRUSH, 
	ERASER
}
