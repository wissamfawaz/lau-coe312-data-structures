package com.wissamfawaz;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
	public static int quotient(int num, int denom) {
		return num / denom; // Throw point
	}

	public static void main(String[] args) {
		int numerator, denominator, output;
		Scanner scan = new Scanner(System.in);
		boolean continueLooping = true;
		
		
		while(continueLooping) {
			try {
				System.out.println("Enter numerator: ");
				numerator = scan.nextInt();
				System.out.println("Enter denominator: ");
				denominator = scan.nextInt();
				
				output = quotient(numerator, denominator);
				System.out.println("Output: " + output);
				
				continueLooping = false;
			} catch(InputMismatchException e) {
				System.out.println("Input must be numeric. Try again");
				scan.nextLine();
			} catch(ArithmeticException e) {
				System.out.println("Denominator cannot be 0. Try again");
			}			
		}
		
		
		
		scan.close();

	}

}
