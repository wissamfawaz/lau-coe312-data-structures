package com.wissamfawaz;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		String productCode;
		Scanner scan = new Scanner(System.in);
		int area, valid = 0, banned = 0;
		char city;
		
		System.out.println("Enter product code (XXX to quit): ");
		productCode = scan.nextLine();
		
		while(!productCode.equals("XXX")) {
			try {
				area = 
				Integer.parseInt(productCode.substring(0, 4));
				city = productCode.charAt(4);
				
				if(area >= 2000 && city == 'B') {
					banned++;
				}
				valid++;
			} catch (NumberFormatException e) {
				System.out.println("Area info must be numeric.");
			} catch(StringIndexOutOfBoundsException e) {
				System.out.println("Code of improper length.");
			}
			System.out.println("Enter product code (XXX to quit): ");
			productCode = scan.nextLine();
			
		}
		
		System.out.println("# valid codes: " + valid);
		System.out.println("# banned codes: " + banned);
		scan.close();
	}

}
